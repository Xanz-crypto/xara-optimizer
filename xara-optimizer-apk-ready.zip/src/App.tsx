import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  INITIAL_DEVICE, 
  INITIAL_KERNEL_SETTINGS, 
  INITIAL_BATTERY_SETTINGS, 
  INITIAL_TELEMETRY, 
  INITIAL_BACKGROUND_APPS, 
  INITIAL_GAMES, 
  INITIAL_LOGS 
} from './data/mockSystem';
import { 
  PrivilegeMode, 
  DeviceHardware, 
  LiveTelemetry, 
  KernelSettings, 
  BatteryOptSettings, 
  BackgroundApp, 
  GameItem, 
  OverlayConfig, 
  TerminalLog 
} from './types/optimizer';
import { HeaderNav } from './components/HeaderNav';
import { SystemTunerHome } from './components/SystemTunerHome';
import { GameSpaceRog } from './components/GameSpaceRog';
import { PerformanceOverlay } from './components/PerformanceOverlay';
import { TerminalDrawer } from './components/TerminalDrawer';
import { PrivilegeModal } from './components/PrivilegeModal';
import { sounds } from './utils/soundEffects';

export default function App() {
  const [activeTab, setActiveTab] = useState<'tuner' | 'gamespace'>('tuner');
  const [privilegeMode, setPrivilegeMode] = useState<PrivilegeMode>('root');
  const [device, setDevice] = useState<DeviceHardware>(INITIAL_DEVICE);
  const [telemetry, setTelemetry] = useState<LiveTelemetry>(INITIAL_TELEMETRY);
  const [kernelSettings, setKernelSettings] = useState<KernelSettings>(INITIAL_KERNEL_SETTINGS);
  const [batterySettings, setBatterySettings] = useState<BatteryOptSettings>(INITIAL_BATTERY_SETTINGS);
  const [backgroundApps, setBackgroundApps] = useState<BackgroundApp[]>(INITIAL_BACKGROUND_APPS);
  const [games, setGames] = useState<GameItem[]>(INITIAL_GAMES);
  const [logs, setLogs] = useState<TerminalLog[]>(INITIAL_LOGS);
  const [soundMuted, setSoundMuted] = useState(false);
  const [xModeActive, setXModeActive] = useState(true);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isPrivilegeModalOpen, setIsPrivilegeModalOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  // Floating Performance Overlay Configuration
  const [overlayConfig, setOverlayConfig] = useState<OverlayConfig>({
    isEnabled: true,
    isExpanded: false,
    hudStyle: 'compact_pill',
    showFps: true,
    showCpu: true,
    showGpu: true,
    showTemp: true,
    showRam: true,
    showFanSpeed: true,
    opacity: 0.95,
    position: { x: 20, y: 75 },
  });

  // Sound sync
  const toggleSound = () => {
    const next = !soundMuted;
    setSoundMuted(next);
    sounds.setMuted(next);
  };

  // Live Telemetry Simulation Loop (Real-time updates)
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry((prev) => {
        // Base CPU usage influenced by X-Mode
        const baseCpu = xModeActive ? 42 : 28;
        const cpuNoise = (Math.random() - 0.5) * 8;
        const newCpu = Math.max(15, Math.min(98, Math.round(baseCpu + cpuNoise)));

        // GPU load fluctuation
        const baseGpu = xModeActive ? 48 : 30;
        const gpuNoise = (Math.random() - 0.5) * 10;
        const newGpu = Math.max(10, Math.min(99, Math.round(baseGpu + gpuNoise)));
        const targetGpuFreq = xModeActive ? 950 : 680;
        const newGpuFreq = Math.round(targetGpuFreq + (Math.random() - 0.5) * 40);

        // FPS based on target refresh rate
        const targetFps = kernelSettings.displayRefreshRateHz;
        const fpsJitter = xModeActive ? (Math.random() - 0.5) * 2 : (Math.random() - 0.5) * 4;
        const newFps = Math.max(50, Math.min(targetFps, targetFps - Math.abs(fpsJitter)));

        // Battery Temperature
        const thermalTarget = batterySettings.bypassChargingEnabled
          ? (xModeActive ? 35.8 : 33.2) // Much cooler with bypass charging
          : (xModeActive ? 41.5 : 37.8);
        const tempNoise = (Math.random() - 0.5) * 0.4;
        const newBattTemp = Math.max(30, Math.min(48, prev.batteryTempC * 0.95 + (thermalTarget + tempNoise) * 0.05));
        const newSocTemp = newBattTemp + 5.2 + (newCpu / 40);

        // Thermal State
        let thermalState: LiveTelemetry['thermalZoneState'] = 'NORMAL';
        if (newBattTemp > 44) thermalState = 'THROTTLED';
        else if (newBattTemp > 40) thermalState = 'HOT';
        else if (newBattTemp > 36) thermalState = 'WARM';

        // CPU Clusters
        const clusters = prev.cpuClusters.map((cluster, i) => {
          const loadNoise = (Math.random() - 0.5) * 6;
          const clusterLoad = Math.max(10, Math.min(100, Math.round(newCpu + loadNoise + (i * 4))));
          const ratio = clusterLoad / 100;
          const freqRange = cluster.maxFreqMhz - cluster.minFreqMhz;
          const targetFreq = xModeActive && i >= 1
            ? cluster.maxFreqMhz - Math.round(Math.random() * 80)
            : Math.round(cluster.minFreqMhz + freqRange * ratio);

          return {
            ...cluster,
            loadPercent: clusterLoad,
            currentFreqMhz: targetFreq,
            governor: kernelSettings.cpuGovernor,
          };
        });

        return {
          ...prev,
          cpuUsagePercent: newCpu,
          cpuClusters: clusters,
          gpuUsagePercent: newGpu,
          gpuFreqMhz: newGpuFreq,
          fps: newFps,
          fpsStabilityPercent: Number((100 - Math.abs(fpsJitter) * 0.8).toFixed(1)),
          batteryTempC: Number(newBattTemp.toFixed(1)),
          socTempC: Number(newSocTemp.toFixed(1)),
          thermalZoneState: thermalState,
          activeRefreshRate: kernelSettings.displayRefreshRateHz,
        };
      });
    }, 1200);

    return () => clearInterval(interval);
  }, [xModeActive, kernelSettings.displayRefreshRateHz, kernelSettings.cpuGovernor, batterySettings.bypassChargingEnabled]);

  // Command logger helper
  const addLog = (cmd: string, out: string, status: 'success' | 'warn' | 'error' = 'success') => {
    const time = new Date().toLocaleTimeString('id-ID', { hour12: false });
    const newLog: TerminalLog = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp: time,
      mode: privilegeMode === 'root' ? 'ROOT' : privilegeMode === 'shizuku' ? 'SHIZUKU' : 'SYS',
      command: cmd,
      output: out,
      status,
    };
    setLogs((prev) => [...prev.slice(-40), newLog]);
  };

  // Toggle X-Mode
  const handleToggleXMode = () => {
    const next = !xModeActive;
    setXModeActive(next);

    if (next) {
      sounds.playXModeActivate();
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.15 },
        colors: ['#ff1a35', '#00f0ff', '#ffb800'],
      });
      setKernelSettings((k) => ({
        ...k,
        cpuGovernor: 'performance',
        adrenoBoostLevel: 'high',
        displayRefreshRateHz: 165,
        touchSamplingRateHz: 720,
      }));
      addLog(
        privilegeMode === 'root' ? 'su -c "setprop debug.rog.xmode 1"' : 'rish -c "setprop debug.rog.xmode 1"',
        'ROG X-Mode Turbo Boost ON: Max CPU/GPU clocks locked. Thermal mitigation bypass active.'
      );
    } else {
      sounds.playToggle(false);
      setKernelSettings((k) => ({
        ...k,
        cpuGovernor: 'schedutil',
        adrenoBoostLevel: 'low',
        displayRefreshRateHz: 120,
      }));
      addLog(
        privilegeMode === 'root' ? 'su -c "setprop debug.rog.xmode 0"' : 'rish -c "setprop debug.rog.xmode 0"',
        'ROG X-Mode deactivated. System restored to dynamic EAS balanced schedutil profile.'
      );
    }
  };

  // 1-Tap Boost & Clear RAM
  const handleBoostRam = () => {
    // Kill cached apps
    setBackgroundApps((apps) =>
      apps.map((app) => (app.isWhitelisted ? app : { ...app, isKilled: true }))
    );

    // Free RAM in telemetry
    setTelemetry((t) => ({
      ...t,
      ramUsedMb: Math.max(4800, t.ramUsedMb - 3250),
      ramFreeMb: Math.min(11500, t.ramFreeMb + 3250),
      ramCachedMb: 850,
      fpsStabilityPercent: 99.8,
    }));

    confetti({
      particleCount: 50,
      spread: 70,
      origin: { y: 0.4 },
      colors: ['#00f0ff', '#10b981', '#ffffff'],
    });

    addLog(
      privilegeMode === 'root' 
        ? 'su -c "echo 3 > /proc/sys/vm/drop_caches && sync"' 
        : 'rish -c "am kill-all && cmd activity drop-caches"',
      'RAM Cleared: 3,250 MB freed. Pagecache, dentries, and inactive task memory dropped successfully.'
    );
  };

  // Kill individual app
  const handleKillApp = (appId: string) => {
    const target = backgroundApps.find((a) => a.id === appId);
    if (!target) return;

    setBackgroundApps((apps) =>
      apps.map((a) => (a.id === appId ? { ...a, isKilled: true } : a))
    );

    setTelemetry((t) => ({
      ...t,
      ramUsedMb: Math.max(4200, t.ramUsedMb - target.ramMb),
      ramFreeMb: t.ramFreeMb + target.ramMb,
    }));

    addLog(
      privilegeMode === 'root'
        ? `su -c "am force-stop ${target.packageName} && killall -9 ${target.packageName}"`
        : `rish -c "am force-stop ${target.packageName}"`,
      `Process killed: ${target.name} (${target.packageName}). Recovered ${target.ramMb} MB RAM.`
    );
  };

  // Kill all non-whitelisted apps
  const handleKillAllApps = () => {
    const totalFreed = backgroundApps
      .filter((a) => !a.isWhitelisted && !a.isKilled)
      .reduce((acc, curr) => acc + curr.ramMb, 0);

    setBackgroundApps((apps) =>
      apps.map((a) => (a.isWhitelisted ? a : { ...a, isKilled: true }))
    );

    setTelemetry((t) => ({
      ...t,
      ramUsedMb: Math.max(4200, t.ramUsedMb - totalFreed),
      ramFreeMb: t.ramFreeMb + totalFreed,
    }));

    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.6 },
    });

    addLog(
      privilegeMode === 'root'
        ? 'su -c "for p in $(dumpsys activity processes | grep -oE \'com\\.[a-zA-Z0-9_.]+\'); do am force-stop $p; done"'
        : 'rish -c "am kill-all"',
      `Mass termination finished. Stopped background processes. Total freed: ${totalFreed} MB RAM.`
    );
  };

  // Scan Apps simulation
  const handleScanApps = () => {
    setIsScanning(true);
    addLog(
      privilegeMode === 'root' ? 'su -c "dumpsys activity processes | grep -i proc"' : 'rish -c "dumpsys meminfo"',
      'Scanning system process tree and background task memory usage...'
    );

    setTimeout(() => {
      setIsScanning(false);
      sounds.playBoostClean();
      addLog(
        'sys',
        `Process inspection completed: ${backgroundApps.length} packages analyzed, 8 background consumers detected.`
      );
    }, 1200);
  };

  // Update Kernel Setting
  const handleUpdateKernel = (newSettings: Partial<KernelSettings>) => {
    setKernelSettings((prev) => {
      const updated = { ...prev, ...newSettings };

      if (newSettings.cpuGovernor) {
        addLog(
          privilegeMode === 'root'
            ? `su -c "for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo '${newSettings.cpuGovernor}' > $g; done"`
            : `rish -c "echo '${newSettings.cpuGovernor}' > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor"`,
          `CPU Governor switched to [${newSettings.cpuGovernor}] on all clusters.`
        );
      }

      if (newSettings.gpuGovernor) {
        addLog(
          privilegeMode === 'root'
            ? `su -c "echo '${newSettings.gpuGovernor}' > /sys/class/kgsl/kgsl-3d0/devfreq/governor"`
            : `rish -c "setprop debug.kgsl.governor ${newSettings.gpuGovernor}"`,
          `Adreno GPU Governor configured to [${newSettings.gpuGovernor}].`
        );
      }

      if (newSettings.displayRefreshRateHz) {
        addLog(
          privilegeMode === 'root'
            ? `su -c "settings put system min_refresh_rate ${newSettings.displayRefreshRateHz}.0 && settings put system peak_refresh_rate ${newSettings.displayRefreshRateHz}.0"`
            : `rish -c "settings put system min_refresh_rate ${newSettings.displayRefreshRateHz}.0"`,
          `Display SurfaceFlinger frame rate locked at ${newSettings.displayRefreshRateHz} Hz.`
        );
      }

      if (newSettings.swappinessPercent !== undefined) {
        addLog(
          privilegeMode === 'root'
            ? `su -c "echo '${newSettings.swappinessPercent}' > /proc/sys/vm/swappiness"`
            : `rish -c "echo '${newSettings.swappinessPercent}' > /proc/sys/vm/swappiness"`,
          `VM Swappiness set to ${newSettings.swappinessPercent}%.`
        );
      }

      return updated;
    });
  };

  // Update Battery Setting
  const handleUpdateBattery = (newSettings: Partial<BatteryOptSettings>) => {
    setBatterySettings((prev) => {
      const updated = { ...prev, ...newSettings };

      if (newSettings.bypassChargingEnabled !== undefined) {
        addLog(
          privilegeMode === 'root'
            ? `su -c "echo '${newSettings.bypassChargingEnabled ? '0' : '1'}' > /sys/class/power_supply/battery/charging_enabled"`
            : `rish -c "dumpsys battery unplug"`,
          newSettings.bypassChargingEnabled
            ? 'Bypass Charging ACTIVATED: Direct power fed to motherboard. Battery charge halted to prevent heat!'
            : 'Standard charging circuit re-enabled.'
        );
      }

      return updated;
    });
  };

  // Execute terminal input
  const handleExecuteCommand = (cmd: string) => {
    let output = '';
    const cleanCmd = cmd.toLowerCase();

    if (cleanCmd.includes('id') || cleanCmd.includes('whoami')) {
      output = privilegeMode === 'root' ? 'uid=0(root) gid=0(root) groups=0(root)' : 'uid=2000(shell) gid=2000(shell)';
    } else if (cleanCmd.includes('drop_caches')) {
      output = '3 > /proc/sys/vm/drop_caches: Dropped clean caches & free buffers. 248MB freed.';
    } else if (cleanCmd.includes('temp') || cleanCmd.includes('thermal')) {
      output = `thermal_zone0: 34200 (34.2°C) [NORMAL]\nthermal_zone1: 37800 (37.8°C) [CPU_SOC]\nthermal_zone2: 32000 (32.0°C) [CHG_VDD]`;
    } else if (cleanCmd.includes('governor')) {
      output = `current_governor: ${kernelSettings.cpuGovernor}\navailable: conservative ondemand userspace powersave performance schedutil`;
    } else if (cleanCmd.includes('refresh_rate')) {
      output = `peak_refresh_rate=${kernelSettings.displayRefreshRateHz}.0\nmin_refresh_rate=${kernelSettings.displayRefreshRateHz}.0`;
    } else if (cleanCmd.includes('force-stop') || cleanCmd.includes('kill')) {
      output = 'ActivityManager: Package stopped successfully.';
    } else if (cleanCmd.includes('getprop') || cleanCmd.includes('ro.product')) {
      output = `ro.product.model=${device.model}\nro.board.platform=kalama\nro.soc.manufacturer=QTI\nro.hardware=qcom`;
    } else {
      output = `Execution OK. Output exit code: 0 [${privilegeMode.toUpperCase()}]`;
    }

    addLog(cmd, output);
  };

  // Add Game to ROG Game Space
  const handleAddGame = (gameData: Omit<GameItem, 'id' | 'playTimeHours' | 'lastPlayed'>) => {
    const newGame: GameItem = {
      ...gameData,
      id: `game-${Date.now()}`,
      playTimeHours: 0,
      lastPlayed: 'Baru ditambahkan',
    };
    setGames((prev) => [newGame, ...prev]);
    addLog(
      'sys',
      `ROG Armoury Crate: Added [${gameData.title}] (${gameData.packageName}) to game profile database.`
    );
  };

  // Update game profile
  const handleUpdateGameConfig = (gameId: string, partial: Partial<GameItem>) => {
    setGames((all) =>
      all.map((g) => (g.id === gameId ? { ...g, ...partial } : g))
    );
  };

  return (
    <div className="min-h-screen bg-[#07090c] text-slate-100 flex flex-col font-chakra selection:bg-red-600 selection:text-white">
      {/* Real-time Floating Draggable Gaming Overlay */}
      <PerformanceOverlay
        telemetry={telemetry}
        config={overlayConfig}
        onUpdateConfig={setOverlayConfig}
        onQuickCleanRam={handleBoostRam}
        xModeActive={xModeActive}
        onToggleXMode={handleToggleXMode}
      />

      {/* Main Header with Navigation & Status Bar */}
      <HeaderNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        privilegeMode={privilegeMode}
        onPrivilegeClick={() => setIsPrivilegeModalOpen(true)}
        telemetry={telemetry}
        onOpenTerminal={() => setIsTerminalOpen(true)}
        overlayConfig={overlayConfig}
        onToggleOverlay={() => setOverlayConfig({ ...overlayConfig, isEnabled: !overlayConfig.isEnabled })}
        soundMuted={soundMuted}
        onToggleSound={toggleSound}
        xModeActive={xModeActive}
        onToggleXMode={handleToggleXMode}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {activeTab === 'tuner' ? (
          /* HOME 1: SYSTEM TUNER, KERNEL & BATTERY & RAM OPTIMIZER */
          <SystemTunerHome
            device={device}
            telemetry={telemetry}
            kernelSettings={kernelSettings}
            batterySettings={batterySettings}
            backgroundApps={backgroundApps}
            privilegeMode={privilegeMode}
            onUpdateKernel={handleUpdateKernel}
            onUpdateBattery={handleUpdateBattery}
            onBoostRam={handleBoostRam}
            onKillApp={handleKillApp}
            onKillAllApps={handleKillAllApps}
            onScanApps={handleScanApps}
            isScanning={isScanning}
            xModeActive={xModeActive}
            onToggleXMode={handleToggleXMode}
            onOpenPrivilegeModal={() => setIsPrivilegeModalOpen(true)}
            onOpenTerminal={() => setIsTerminalOpen(true)}
          />
        ) : (
          /* HOME 2: ROG GAME SPACE (ARMOURY CRATE DUAL HOMEPAGE) */
          <GameSpaceRog
            games={games}
            telemetry={telemetry}
            xModeActive={xModeActive}
            onToggleXMode={handleToggleXMode}
            overlayConfig={overlayConfig}
            onToggleOverlay={() => setOverlayConfig({ ...overlayConfig, isEnabled: !overlayConfig.isEnabled })}
            onQuickCleanRam={handleBoostRam}
            onUpdateGameConfig={handleUpdateGameConfig}
            onAddGame={handleAddGame}
          />
        )}
      </main>

      {/* Footer System Info */}
      <footer className="border-t border-[#1b2332] bg-[#07090c] py-4 text-xs text-slate-500 font-mono-code text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            <span>XARA OPTIMIZER &bull; ROG GAME SPACE HYBRID ENGINE</span>
          </div>
          <div>
            Metode: <span className="text-white font-bold">{privilegeMode.toUpperCase()}</span> | Kernel:{' '}
            <span className="text-slate-400">{device.kernel.split('-')[0]}</span> | 165Hz Display Lock
          </div>
        </div>
      </footer>

      {/* Slide-out Terminal Shell Logs & Script Exporter */}
      <TerminalDrawer
        isOpen={isTerminalOpen}
        onClose={() => setIsTerminalOpen(false)}
        logs={logs}
        onClearLogs={() => setLogs([])}
        onExecuteCommand={handleExecuteCommand}
        kernelSettings={kernelSettings}
        batterySettings={batterySettings}
        privilegeMode={privilegeMode}
      />

      {/* Root & Shizuku Privilege Selector Modal */}
      <PrivilegeModal
        isOpen={isPrivilegeModalOpen}
        onClose={() => setIsPrivilegeModalOpen(false)}
        currentMode={privilegeMode}
        onSelectMode={(m) => {
          setPrivilegeMode(m);
          setIsPrivilegeModalOpen(false);
          addLog('sys', `Privilege execution bridge updated to: [${m.toUpperCase()}].`);
        }}
        device={device}
      />
    </div>
  );
}
