export type PrivilegeMode = 'root' | 'shizuku' | 'standard';

export interface DeviceHardware {
  model: string;
  codename: string;
  soc: string;
  kernel: string;
  androidVersion: string;
  securityPatch: string;
  totalRamMb: number;
  totalStorageGb: number;
  batteryCapacityMah: number;
  maxRefreshRate: number;
  rootProvider?: 'KernelSU' | 'Magisk v27.0' | 'APatch' | null;
  shizukuVersion?: string | null;
  selinuxMode: 'Enforcing' | 'Permissive';
}

export interface CpuCluster {
  name: string;
  cores: string;
  currentFreqMhz: number;
  minFreqMhz: number;
  maxFreqMhz: number;
  governor: string;
  loadPercent: number;
}

export interface LiveTelemetry {
  cpuUsagePercent: number;
  cpuClusters: CpuCluster[];
  gpuUsagePercent: number;
  gpuFreqMhz: number;
  maxGpuFreqMhz: number;
  ramUsedMb: number;
  ramCachedMb: number;
  ramFreeMb: number;
  ramTotalMb: number;
  fps: number;
  fpsStabilityPercent: number;
  temperatureC: number;
  batteryTempC: number;
  socTempC: number;
  batteryLevelPercent: number;
  batteryVoltageMv: number;
  batteryCurrentMa: number;
  chargingStatus: 'discharging' | 'charging' | 'bypass_powered' | 'full';
  thermalZoneState: 'NORMAL' | 'WARM' | 'HOT' | 'THROTTLED' | 'COOLING_ACTIVE';
  activeRefreshRate: number;
}

export interface KernelSettings {
  cpuGovernor: 'schedutil' | 'performance' | 'powersave' | 'ondemand' | 'conservative';
  thermalThrottling: 'stock' | 'gaming_bypass' | 'aggressive_cool' | 'disabled_extreme';
  gpuGovernor: 'msm-adreno-tz' | 'simple_ondemand' | 'performance' | 'powersave';
  adrenoBoostLevel: 'off' | 'low' | 'medium' | 'high';
  ioScheduler: 'mq-deadline' | 'kyber' | 'bfq' | 'none';
  tcpCongestion: 'bbr' | 'cubic' | 'westwood';
  swappinessPercent: number;
  zramSizeMb: number;
  zramCompression: 'lz4' | 'zstd' | 'lzo';
  touchSamplingRateHz: 240 | 360 | 480 | 720;
  displayRefreshRateHz: 60 | 90 | 120 | 144 | 165;
  disableHwOverlays: boolean;
  forceGpuRendering: boolean;
  bclControl: boolean; // Battery Current Limiter
}

export interface BatteryOptSettings {
  mode: 'gaming_bypass' | 'balanced_ai' | 'ultra_saver' | 'cooldown_guard';
  bypassChargingEnabled: boolean; // Direct motherboard power
  chargeLimitPercent: number; // 80% / 90% / 100%
  thermalSafeCutoffC: number;
  deepSleepKillBackground: boolean;
  adaptiveBrightnessBoost: boolean;
}

export interface BackgroundApp {
  id: string;
  name: string;
  packageName: string;
  category: 'games' | 'social' | 'media' | 'system' | 'bloatware';
  ramMb: number;
  cpuPercent: number;
  runningSinceMinutes: number;
  isKilled: boolean;
  isWhitelisted: boolean;
  importance: 'foreground' | 'cached' | 'service';
}

export interface GameItem {
  id: string;
  title: string;
  packageName: string;
  genre: string;
  coverImage: string;
  targetFps: 60 | 90 | 120 | 144 | 165;
  resolutionScalePercent: number;
  touchSensitivity: number; // 1-10
  audioEnhanced: boolean;
  networkAntiJitter: boolean;
  bypassCharging: boolean;
  blockCallsAndNotifications: boolean;
  lastPlayed: string;
  playTimeHours: number;
}

export interface OverlayConfig {
  isEnabled: boolean;
  isExpanded: boolean;
  hudStyle: 'compact_pill' | 'gaming_hud' | 'horizontal_bar';
  showFps: boolean;
  showCpu: boolean;
  showGpu: boolean;
  showTemp: boolean;
  showRam: boolean;
  showFanSpeed: boolean;
  opacity: number;
  position: { x: number; y: number };
}

export interface TerminalLog {
  id: string;
  timestamp: string;
  mode: 'ROOT' | 'SHIZUKU' | 'SYS';
  command: string;
  output: string;
  status: 'success' | 'warn' | 'error';
}
