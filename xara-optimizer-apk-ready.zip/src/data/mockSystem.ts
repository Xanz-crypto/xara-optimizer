import { BackgroundApp, DeviceHardware, GameItem, KernelSettings, BatteryOptSettings, LiveTelemetry, TerminalLog } from '../types/optimizer';

export const INITIAL_DEVICE: DeviceHardware = {
  model: 'ASUS ROG Phone 8 Pro (Global Edition)',
  codename: 'AI2401',
  soc: 'Qualcomm Snapdragon 8 Gen 3 (SM8650-AB)',
  kernel: 'Linux 6.1.75-android14-11-g619b02a-XaraKernel-perf+',
  androidVersion: 'Android 14 (ROG UI 8.0)',
  securityPatch: '2026-10-05',
  totalRamMb: 16384, // 16 GB
  totalStorageGb: 512,
  batteryCapacityMah: 5500,
  maxRefreshRate: 165,
  rootProvider: 'KernelSU',
  shizukuVersion: 'v13.5.4 (rish v3.2 / Port 5555)',
  selinuxMode: 'Permissive',
};

export const INITIAL_KERNEL_SETTINGS: KernelSettings = {
  cpuGovernor: 'performance',
  thermalThrottling: 'gaming_bypass',
  gpuGovernor: 'msm-adreno-tz',
  adrenoBoostLevel: 'high',
  ioScheduler: 'mq-deadline',
  tcpCongestion: 'bbr',
  swappinessPercent: 60,
  zramSizeMb: 8192,
  zramCompression: 'lz4',
  touchSamplingRateHz: 720,
  displayRefreshRateHz: 165,
  disableHwOverlays: true,
  forceGpuRendering: true,
  bclControl: false,
};

export const INITIAL_BATTERY_SETTINGS: BatteryOptSettings = {
  mode: 'gaming_bypass',
  bypassChargingEnabled: true,
  chargeLimitPercent: 80,
  thermalSafeCutoffC: 45,
  deepSleepKillBackground: true,
  adaptiveBrightnessBoost: false,
};

export const INITIAL_TELEMETRY: LiveTelemetry = {
  cpuUsagePercent: 38,
  cpuClusters: [
    {
      name: 'LITTLE (Cluster 0)',
      cores: 'Core 0-1 (Cortex-A520)',
      currentFreqMhz: 1843,
      minFreqMhz: 633,
      maxFreqMhz: 2265,
      governor: 'schedutil',
      loadPercent: 32,
    },
    {
      name: 'BIG (Cluster 1)',
      cores: 'Core 2-6 (Cortex-A720)',
      currentFreqMhz: 2688,
      minFreqMhz: 864,
      maxFreqMhz: 3148,
      governor: 'performance',
      loadPercent: 44,
    },
    {
      name: 'PRIME (Cluster 2)',
      cores: 'Core 7 (Cortex-X4)',
      currentFreqMhz: 3187,
      minFreqMhz: 998,
      maxFreqMhz: 3302,
      governor: 'performance',
      loadPercent: 51,
    },
  ],
  gpuUsagePercent: 42,
  gpuFreqMhz: 680,
  maxGpuFreqMhz: 1000,
  ramUsedMb: 9420,
  ramCachedMb: 3120,
  ramFreeMb: 3844,
  ramTotalMb: 16384,
  fps: 164,
  fpsStabilityPercent: 99.4,
  temperatureC: 37.8,
  batteryTempC: 34.2,
  socTempC: 41.5,
  batteryLevelPercent: 84,
  batteryVoltageMv: 4192,
  batteryCurrentMa: -340,
  chargingStatus: 'bypass_powered',
  thermalZoneState: 'NORMAL',
  activeRefreshRate: 165,
};

export const INITIAL_BACKGROUND_APPS: BackgroundApp[] = [
  {
    id: 'app-1',
    name: 'Mobile Legends: Bang Bang',
    packageName: 'com.mobile.legends',
    category: 'games',
    ramMb: 1480,
    cpuPercent: 18.4,
    runningSinceMinutes: 45,
    isKilled: false,
    isWhitelisted: true,
    importance: 'foreground',
  },
  {
    id: 'app-2',
    name: 'TikTok',
    packageName: 'com.zhiliaoapp.musically',
    category: 'social',
    ramMb: 760,
    cpuPercent: 6.8,
    runningSinceMinutes: 120,
    isKilled: false,
    isWhitelisted: false,
    importance: 'cached',
  },
  {
    id: 'app-3',
    name: 'Instagram',
    packageName: 'com.instagram.android',
    category: 'social',
    ramMb: 680,
    cpuPercent: 4.2,
    runningSinceMinutes: 210,
    isKilled: false,
    isWhitelisted: false,
    importance: 'cached',
  },
  {
    id: 'app-4',
    name: 'Shopee ID',
    packageName: 'com.shopee.id',
    category: 'bloatware',
    ramMb: 520,
    cpuPercent: 5.1,
    runningSinceMinutes: 340,
    isKilled: false,
    isWhitelisted: false,
    importance: 'service',
  },
  {
    id: 'app-5',
    name: 'Google Chrome',
    packageName: 'com.android.chrome',
    category: 'media',
    ramMb: 920,
    cpuPercent: 3.9,
    runningSinceMinutes: 85,
    isKilled: false,
    isWhitelisted: false,
    importance: 'cached',
  },
  {
    id: 'app-6',
    name: 'WhatsApp Messenger',
    packageName: 'com.whatsapp',
    category: 'social',
    ramMb: 390,
    cpuPercent: 1.5,
    runningSinceMinutes: 720,
    isKilled: false,
    isWhitelisted: true,
    importance: 'service',
  },
  {
    id: 'app-7',
    name: 'YouTube',
    packageName: 'com.google.android.youtube',
    category: 'media',
    ramMb: 640,
    cpuPercent: 2.1,
    runningSinceMinutes: 65,
    isKilled: false,
    isWhitelisted: false,
    importance: 'cached',
  },
  {
    id: 'app-8',
    name: 'Analytics Tracker Daemon',
    packageName: 'com.qualcomm.qti.optdaemon',
    category: 'bloatware',
    ramMb: 310,
    cpuPercent: 4.8,
    runningSinceMinutes: 890,
    isKilled: false,
    isWhitelisted: false,
    importance: 'service',
  },
  {
    id: 'app-9',
    name: 'Spotify Music',
    packageName: 'com.spotify.music',
    category: 'media',
    ramMb: 410,
    cpuPercent: 2.4,
    runningSinceMinutes: 180,
    isKilled: false,
    isWhitelisted: false,
    importance: 'service',
  },
  {
    id: 'app-10',
    name: 'Telegram Messenger',
    packageName: 'org.telegram.messenger',
    category: 'social',
    ramMb: 360,
    cpuPercent: 1.2,
    runningSinceMinutes: 420,
    isKilled: false,
    isWhitelisted: false,
    importance: 'cached',
  },
];

export const INITIAL_GAMES: GameItem[] = [
  {
    id: 'game-1',
    title: 'Mobile Legends: Bang Bang',
    packageName: 'com.mobile.legends',
    genre: 'MOBA 5v5',
    coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop',
    targetFps: 120,
    resolutionScalePercent: 100,
    touchSensitivity: 9,
    audioEnhanced: true,
    networkAntiJitter: true,
    bypassCharging: true,
    blockCallsAndNotifications: true,
    lastPlayed: '15 menit lalu',
    playTimeHours: 142.5,
  },
  {
    id: 'game-2',
    title: 'Genshin Impact',
    packageName: 'com.miHoYo.GenshinImpact',
    genre: 'Open-World Action RPG',
    coverImage: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=800&auto=format&fit=crop',
    targetFps: 90,
    resolutionScalePercent: 90,
    touchSensitivity: 8,
    audioEnhanced: true,
    networkAntiJitter: true,
    bypassCharging: true,
    blockCallsAndNotifications: true,
    lastPlayed: 'Kemarin',
    playTimeHours: 215.2,
  },
  {
    id: 'game-3',
    title: 'PUBG Mobile',
    packageName: 'com.tencent.ig',
    genre: 'Battle Royale',
    coverImage: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=800&auto=format&fit=crop',
    targetFps: 120,
    resolutionScalePercent: 100,
    touchSensitivity: 10,
    audioEnhanced: true,
    networkAntiJitter: true,
    bypassCharging: true,
    blockCallsAndNotifications: true,
    lastPlayed: '3 hari lalu',
    playTimeHours: 89.0,
  },
  {
    id: 'game-4',
    title: 'Free Fire MAX',
    packageName: 'com.dts.freefiremax',
    genre: 'Survival Shooter',
    coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop',
    targetFps: 165,
    resolutionScalePercent: 100,
    touchSensitivity: 10,
    audioEnhanced: false,
    networkAntiJitter: true,
    bypassCharging: true,
    blockCallsAndNotifications: true,
    lastPlayed: '5 hari lalu',
    playTimeHours: 64.3,
  },
  {
    id: 'game-5',
    title: 'Honor of Kings',
    packageName: 'com.levelinfinite.sgameGlobal',
    genre: 'MOBA Mobile',
    coverImage: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=800&auto=format&fit=crop',
    targetFps: 120,
    resolutionScalePercent: 100,
    touchSensitivity: 9,
    audioEnhanced: true,
    networkAntiJitter: true,
    bypassCharging: true,
    blockCallsAndNotifications: true,
    lastPlayed: '1 minggu lalu',
    playTimeHours: 32.8,
  },
  {
    id: 'game-6',
    title: 'Call of Duty: Warzone Mobile',
    packageName: 'com.activision.callofduty.warzone',
    genre: 'FPS Battle Royale',
    coverImage: 'https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=800&auto=format&fit=crop',
    targetFps: 120,
    resolutionScalePercent: 95,
    touchSensitivity: 10,
    audioEnhanced: true,
    networkAntiJitter: true,
    bypassCharging: true,
    blockCallsAndNotifications: true,
    lastPlayed: '2 minggu lalu',
    playTimeHours: 41.5,
  },
];

export const INITIAL_LOGS: TerminalLog[] = [
  {
    id: 'log-1',
    timestamp: '20:41:02',
    mode: 'ROOT',
    command: 'su -c "id; whoami"',
    output: 'uid=0(root) gid=0(root) groups=0(root) context=u:r:magisk:s0',
    status: 'success',
  },
  {
    id: 'log-2',
    timestamp: '20:41:03',
    mode: 'SHIZUKU',
    command: 'rish -c "shizuku_check_service"',
    output: 'Shizuku service alive on IPC port 5555. Token verified.',
    status: 'success',
  },
  {
    id: 'log-3',
    timestamp: '20:41:05',
    mode: 'SYS',
    command: 'cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors',
    output: 'conservative ondemand userspace powersave performance schedutil',
    status: 'success',
  },
  {
    id: 'log-4',
    timestamp: '20:41:08',
    mode: 'ROOT',
    command: 'echo "performance" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor',
    output: 'Policy 0 (Cluster Little) governor locked to [performance].',
    status: 'success',
  },
  {
    id: 'log-5',
    timestamp: '20:41:10',
    mode: 'ROOT',
    command: 'echo "1" > /sys/class/power_supply/battery/charging_enabled',
    output: 'Bypass charging controller initialized. Direct VDD supply set.',
    status: 'success',
  },
];

export function generateShellScript(kernel: KernelSettings, battery: BatteryOptSettings, mode: 'root' | 'shizuku'): string {
  const prefix = mode === 'root' ? 'su -c' : 'rish -c';
  
  return `#!/system/bin/sh
# ==============================================================================
# XARA OPTIMIZER & ROG GAME SPACE KERNEL TUNER SCRIPT
# Generated for: Snapdragon 8 Gen 3 / ARM64
# Execution Mode: ${mode.toUpperCase()}
# Generated at: ${new Date().toISOString()}
# ==============================================================================

echo "[XARA] Initializing High-Performance Gaming Tweaks..."

# 1. CPU GOVERNOR SETUP
echo "[XARA] Setting CPU Governor: ${kernel.cpuGovernor}..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu" ] && ${prefix} "echo '${kernel.cpuGovernor}' > $cpu"
done

# 2. GPU TUNING & ADRENOBOOST
echo "[XARA] Setting GPU Governor: ${kernel.gpuGovernor}..."
if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
    ${prefix} "echo '${kernel.gpuGovernor}' > /sys/class/kgsl/kgsl-3d0/devfreq/governor"
    ${prefix} "echo '${kernel.adrenoBoostLevel === 'high' ? '3' : kernel.adrenoBoostLevel === 'medium' ? '2' : '1'}' > /sys/class/kgsl/kgsl-3d0/adrenoboost"
    ${prefix} "echo '0' > /sys/class/kgsl/kgsl-3d0/bus_split"
fi

# 3. THERMAL THROTTLING OVERRIDE
echo "[XARA] Setting Thermal Mitigation Mode: ${kernel.thermalThrottling}..."
${prefix} "stop thermald 2>/dev/null"
${prefix} "stop thermal-engine 2>/dev/null"
if [ "${kernel.thermalThrottling}" = "gaming_bypass" ]; then
    ${prefix} "echo '0' > /sys/devices/virtual/thermal/thermal_zone*/mode 2>/dev/null"
fi

# 4. MEMORY & VIRTUAL MEMORY (ZRAM / SWAPPINESS)
echo "[XARA] Optimizing VM Swappiness: ${kernel.swappinessPercent}%..."
${prefix} "echo '${kernel.swappinessPercent}' > /proc/sys/vm/swappiness"
${prefix} "echo '100' > /proc/sys/vm/vfs_cache_pressure"
${prefix} "echo '0' > /proc/sys/vm/page-cluster"
${prefix} "echo '3' > /proc/sys/vm/drop_caches"

# 5. I/O SCHEDULER & TCP CONGESTION
echo "[XARA] Setting IO Scheduler (${kernel.ioScheduler}) & TCP (${kernel.tcpCongestion})..."
for queue in /sys/block/*/queue/scheduler; do
    [ -f "$queue" ] && ${prefix} "echo '${kernel.ioScheduler}' > $queue"
done
${prefix} "echo '${kernel.tcpCongestion}' > /proc/sys/net/ipv4/tcp_congestion_control"

# 6. DISPLAY REFRESH RATE & SURFACEFLINGER BUFFER
echo "[XARA] Locking Display Refresh Rate to ${kernel.displayRefreshRateHz} Hz..."
${prefix} "settings put system peak_refresh_rate ${kernel.displayRefreshRateHz}.0"
${prefix} "settings put system min_refresh_rate ${kernel.displayRefreshRateHz}.0"
${prefix} "service call SurfaceFlinger 1008 i32 ${kernel.disableHwOverlays ? '1' : '0'}"

# 7. BATTERY BYPASS CHARGING (ROG DIRECT POWER)
${battery.bypassChargingEnabled ? `echo "[XARA] Enabling Motherboard Bypass Charging to stop battery heating..."
${prefix} "echo '0' > /sys/class/power_supply/battery/charging_enabled 2>/dev/null"
${prefix} "echo '1' > /sys/class/power_supply/battery/input_suspend 2>/dev/null"
${prefix} "echo '1' > /sys/class/power_supply/battery/bypass_charger 2>/dev/null"` : '# Bypass charging disabled'}

echo "[XARA] ✅ Optimization Complete! ROG Game Space Ready."
`;
}
