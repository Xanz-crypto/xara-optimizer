import React, { useState, useRef, useEffect } from 'react';
import { 
  Activity, 
  X, 
  Minimize2, 
  Maximize2, 
  Sparkles, 
  BellOff, 
  Crosshair, 
  Snowflake, 
  GripHorizontal,
  Flame,
  Zap,
  Lock,
  Cpu,
  SlidersHorizontal
} from 'lucide-react';
import { LiveTelemetry, OverlayConfig } from '../types/optimizer';
import { sounds } from '../utils/soundEffects';

interface PerformanceOverlayProps {
  telemetry: LiveTelemetry;
  config: OverlayConfig;
  onUpdateConfig: (config: OverlayConfig) => void;
  onQuickCleanRam: () => void;
  xModeActive: boolean;
  onToggleXMode: () => void;
}

export const PerformanceOverlay: React.FC<PerformanceOverlayProps> = ({
  telemetry,
  config,
  onUpdateConfig,
  onQuickCleanRam,
  xModeActive,
  onToggleXMode,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState(config.position || { x: 24, y: 84 });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [showCrosshair, setShowCrosshair] = useState(false);
  const [dndBlocked, setDndBlocked] = useState(true);
  const [fpsLock, setFpsLock] = useState<number>(165);
  const [fpsHistory, setFpsHistory] = useState<number[]>([164, 165, 163, 165, 164, 165, 164, 165]);

  // Keep track of FPS history for live mini graph
  useEffect(() => {
    setFpsHistory((prev) => [...prev.slice(-15), Math.round(telemetry.fps)]);
  }, [telemetry.fps]);

  // Handle Dragging
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const maxX = window.innerWidth - 300;
    const maxY = window.innerHeight - 200;
    const newX = Math.max(10, Math.min(maxX, e.clientX - dragOffset.x));
    const newY = Math.max(60, Math.min(maxY, e.clientY - dragOffset.y));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    onUpdateConfig({ ...config, position });
  };

  if (!config.isEnabled) return null;

  return (
    <>
      {/* Optional In-Game Crosshair Overlay */}
      {showCrosshair && (
        <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center">
          <div className="relative w-8 h-8">
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-red-500 shadow-[0_0_8px_#ff1a35]"></div>
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-red-500 shadow-[0_0_8px_#ff1a35]"></div>
            <div className="absolute inset-1 border border-cyan-400 rounded-full opacity-70"></div>
            <div className="absolute inset-3 bg-red-500 rounded-full"></div>
          </div>
        </div>
      )}

      {/* Floating HUD Widget */}
      <div
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          touchAction: 'none',
        }}
        className={`fixed z-50 select-none transition-shadow ${
          isDragging ? 'shadow-2xl shadow-cyan-900/60 scale-[1.02]' : ''
        }`}
      >
        {/* COMPACT MODE */}
        {!config.isExpanded ? (
          <div className="bg-[#0b0e14]/90 backdrop-blur-md border border-cyan-500/70 rounded-full px-3 py-1.5 flex items-center space-x-3 text-xs font-mono-code text-white shadow-xl glow-cyan-sm cursor-move">
            <div
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              className="flex items-center space-x-2 text-cyan-400 cursor-grab active:cursor-grabbing"
            >
              <GripHorizontal className="w-3.5 h-3.5 text-slate-500" />
              <div className="flex items-center space-x-1">
                <span className="text-[10px] text-slate-400 font-chakra font-bold">FPS</span>
                <span className="font-bold text-cyan-300 text-sm">{Math.round(telemetry.fps)}</span>
              </div>
            </div>

            <span className="text-slate-600">|</span>

            <div className="flex items-center space-x-1.5">
              <span className="text-[10px] text-slate-400">CPU</span>
              <span className={`font-semibold ${telemetry.cpuUsagePercent > 70 ? 'text-red-400' : 'text-slate-200'}`}>
                {Math.round(telemetry.cpuUsagePercent)}%
              </span>
            </div>

            <span className="text-slate-600">|</span>

            <div className="flex items-center space-x-1.5">
              <span className="text-[10px] text-slate-400">GPU</span>
              <span className="text-amber-400 font-semibold">{Math.round(telemetry.gpuUsagePercent)}%</span>
            </div>

            <span className="text-slate-600">|</span>

            <div className="flex items-center space-x-1.5">
              <span className="text-[10px] text-slate-400">TEMP</span>
              <span className={`font-semibold ${telemetry.batteryTempC > 40 ? 'text-red-400 animate-pulse' : 'text-emerald-400'}`}>
                {telemetry.batteryTempC.toFixed(0)}°C
              </span>
            </div>

            {/* Expand button */}
            <button
              onClick={() => {
                sounds.playClick();
                onUpdateConfig({ ...config, isExpanded: true });
              }}
              className="p-1 hover:bg-[#1a2332] rounded text-slate-400 hover:text-cyan-400 transition-colors ml-1"
              title="Perluas ROG Game Genie Panel"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
        ) : (
          /* EXPANDED GAMING HUD MODE (ROG ARMOURY CRATE OVERLAY) */
          <div className="w-[320px] bg-[#090c12]/95 backdrop-blur-xl border border-red-900/60 rounded-2xl shadow-2xl overflow-hidden clip-corner-both glow-red-sm">
            {/* Header Drag Handle */}
            <div
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              className="bg-gradient-to-r from-red-950/80 via-[#151c27] to-[#0c1017] px-3.5 py-2 flex items-center justify-between border-b border-[#222c3c] cursor-grab active:cursor-grabbing"
            >
              <div className="flex items-center space-x-2">
                <GripHorizontal className="w-4 h-4 text-slate-500" />
                <span className="text-xs font-chakra font-black tracking-widest text-red-500 flex items-center gap-1">
                  ROG <span className="text-white">GAME GENIE</span>
                </span>
                <span className="text-[9px] px-1.5 py-0.5 bg-red-900/40 text-red-400 rounded font-mono-code border border-red-800/40">
                  REAL-TIME HUD
                </span>
              </div>

              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() => {
                    sounds.playClick();
                    onUpdateConfig({ ...config, isExpanded: false });
                  }}
                  className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded"
                  title="Minimize ke mode pil"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    sounds.playClick();
                    onUpdateConfig({ ...config, isEnabled: false });
                  }}
                  className="p-1 hover:bg-red-900/50 text-slate-400 hover:text-red-400 rounded"
                  title="Tutup Overlay"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Telemetry Display Grid */}
            <div className="p-3 space-y-2.5">
              {/* FPS Counter & Mini Graph */}
              <div className="bg-[#121722] border border-[#20293a] rounded-xl p-2.5 flex items-center justify-between">
                <div>
                  <div className="flex items-baseline space-x-1.5">
                    <span className="text-2xl font-chakra font-black text-white text-glow-cyan">
                      {Math.round(telemetry.fps)}
                    </span>
                    <span className="text-xs text-cyan-400 font-bold font-chakra">FPS</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono-code flex items-center space-x-2">
                    <span>Target: {fpsLock}Hz</span>
                    <span>•</span>
                    <span className="text-emerald-400">Stabilitas: {telemetry.fpsStabilityPercent}%</span>
                  </div>
                </div>

                {/* Sparkline Visual */}
                <div className="flex items-end space-x-1 h-8 w-24">
                  {fpsHistory.map((val, idx) => {
                    const heightPercent = Math.min(100, Math.max(20, (val / fpsLock) * 100));
                    return (
                      <div
                        key={idx}
                        style={{ height: `${heightPercent}%` }}
                        className={`w-1 rounded-t transition-all duration-300 ${
                          val >= fpsLock - 5 ? 'bg-cyan-400' : val >= fpsLock - 15 ? 'bg-amber-400' : 'bg-red-500'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* CPU & GPU Dual Cards */}
              <div className="grid grid-cols-2 gap-2">
                {/* CPU */}
                <div className="bg-[#121722] border border-[#20293a] rounded-xl p-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <span className="font-chakra font-bold text-white flex items-center gap-1">
                      <Cpu className="w-3 h-3 text-cyan-400" /> CPU
                    </span>
                    <span className="font-mono-code text-cyan-300 font-bold">{Math.round(telemetry.cpuUsagePercent)}%</span>
                  </div>
                  <div className="w-full bg-[#0a0d14] h-1.5 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${telemetry.cpuUsagePercent}%` }}
                      className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-500"
                    />
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono-code mt-1 flex justify-between">
                    <span>X4 Prime</span>
                    <span className="text-slate-300">{telemetry.cpuClusters[2]?.currentFreqMhz}MHz</span>
                  </div>
                </div>

                {/* GPU */}
                <div className="bg-[#121722] border border-[#20293a] rounded-xl p-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <span className="font-chakra font-bold text-white flex items-center gap-1">
                      <Zap className="w-3 h-3 text-amber-400" /> GPU
                    </span>
                    <span className="font-mono-code text-amber-400 font-bold">{Math.round(telemetry.gpuUsagePercent)}%</span>
                  </div>
                  <div className="w-full bg-[#0a0d14] h-1.5 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${telemetry.gpuUsagePercent}%` }}
                      className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-500"
                    />
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono-code mt-1 flex justify-between">
                    <span>Adreno 750</span>
                    <span className="text-slate-300">{telemetry.gpuFreqMhz}MHz</span>
                  </div>
                </div>
              </div>

              {/* Temp & RAM Details */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                {/* Temp */}
                <div className="bg-[#121722] border border-[#20293a] rounded-xl p-2 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-slate-400 font-chakra uppercase">SUHU BATERAI</div>
                    <div className={`text-base font-chakra font-bold ${
                      telemetry.batteryTempC > 40 ? 'text-red-400' : telemetry.batteryTempC > 36 ? 'text-amber-400' : 'text-emerald-400'
                    }`}>
                      {telemetry.batteryTempC.toFixed(1)}°C
                    </div>
                  </div>
                  <div className="text-[10px] font-mono-code text-right text-slate-400">
                    <div>SoC: {telemetry.socTempC.toFixed(1)}°C</div>
                    <div className="text-emerald-400">Bypass OK</div>
                  </div>
                </div>

                {/* RAM */}
                <div className="bg-[#121722] border border-[#20293a] rounded-xl p-2 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-slate-400 font-chakra uppercase">RAM DIGUNAKAN</div>
                    <div className="text-base font-chakra font-bold text-white">
                      {(telemetry.ramUsedMb / 1024).toFixed(1)} <span className="text-xs font-normal text-slate-400">/ 16GB</span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      sounds.playBoostClean();
                      onQuickCleanRam();
                    }}
                    className="p-1.5 bg-red-950/60 hover:bg-red-800 text-red-400 hover:text-white rounded-lg border border-red-700/60 transition-colors"
                    title="Bersihkan RAM Langsung"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* In-Game Game Genie Quick Tool Strip */}
              <div className="pt-1 border-t border-[#1d2533]">
                <div className="text-[10px] text-slate-400 font-chakra uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <span>ROG In-Game Tools</span>
                  <span className="text-red-400 font-bold">X-MODE</span>
                </div>

                <div className="grid grid-cols-4 gap-1.5">
                  {/* Clean RAM */}
                  <button
                    onClick={() => {
                      sounds.playBoostClean();
                      onQuickCleanRam();
                    }}
                    className="flex flex-col items-center justify-center p-1.5 bg-[#141b27] hover:bg-[#1f2838] rounded-lg border border-[#232d3d] text-slate-300 hover:text-cyan-400 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400 mb-0.5" />
                    <span className="text-[9px] font-chakra font-semibold">Clean RAM</span>
                  </button>

                  {/* Crosshair Overlay */}
                  <button
                    onClick={() => {
                      sounds.playToggle(!showCrosshair);
                      setShowCrosshair(!showCrosshair);
                    }}
                    className={`flex flex-col items-center justify-center p-1.5 rounded-lg border transition-colors ${
                      showCrosshair
                        ? 'bg-red-950/80 text-red-400 border-red-600'
                        : 'bg-[#141b27] hover:bg-[#1f2838] text-slate-300 border-[#232d3d]'
                    }`}
                  >
                    <Crosshair className="w-3.5 h-3.5 text-red-400 mb-0.5" />
                    <span className="text-[9px] font-chakra font-semibold">Crosshair</span>
                  </button>

                  {/* Block Notifs */}
                  <button
                    onClick={() => {
                      sounds.playToggle(!dndBlocked);
                      setDndBlocked(!dndBlocked);
                    }}
                    className={`flex flex-col items-center justify-center p-1.5 rounded-lg border transition-colors ${
                      dndBlocked
                        ? 'bg-amber-950/80 text-amber-300 border-amber-600'
                        : 'bg-[#141b27] hover:bg-[#1f2838] text-slate-300 border-[#232d3d]'
                    }`}
                  >
                    <BellOff className="w-3.5 h-3.5 text-amber-400 mb-0.5" />
                    <span className="text-[9px] font-chakra font-semibold">Block Notif</span>
                  </button>

                  {/* X-Mode Overclock */}
                  <button
                    onClick={() => {
                      onToggleXMode();
                    }}
                    className={`flex flex-col items-center justify-center p-1.5 rounded-lg border transition-colors ${
                      xModeActive
                        ? 'bg-red-600 text-white border-red-400 shadow-md shadow-red-900/60 animate-pulse'
                        : 'bg-[#141b27] hover:bg-[#1f2838] text-slate-300 border-[#232d3d]'
                    }`}
                  >
                    <Flame className="w-3.5 h-3.5 text-amber-300 mb-0.5" />
                    <span className="text-[9px] font-chakra font-semibold">X-Mode</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
