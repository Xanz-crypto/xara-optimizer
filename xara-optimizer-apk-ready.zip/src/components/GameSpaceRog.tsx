import React, { useState } from 'react';
import { 
  Gamepad2, 
  Flame, 
  Play, 
  Sliders, 
  Crosshair, 
  BellOff, 
  Zap, 
  Activity, 
  Sparkles, 
  Wifi, 
  Headphones, 
  CheckCircle2, 
  Plus, 
  X, 
  ShieldCheck, 
  Cpu, 
  Clock, 
  ChevronRight,
  Maximize2
} from 'lucide-react';
import { GameItem, LiveTelemetry, OverlayConfig } from '../types/optimizer';
import { sounds } from '../utils/soundEffects';

interface GameSpaceRogProps {
  games: GameItem[];
  telemetry: LiveTelemetry;
  xModeActive: boolean;
  onToggleXMode: () => void;
  overlayConfig: OverlayConfig;
  onToggleOverlay: () => void;
  onQuickCleanRam: () => void;
  onUpdateGameConfig: (gameId: string, partial: Partial<GameItem>) => void;
  onAddGame: (game: Omit<GameItem, 'id' | 'playTimeHours' | 'lastPlayed'>) => void;
}

export const GameSpaceRog: React.FC<GameSpaceRogProps> = ({
  games,
  telemetry,
  xModeActive,
  onToggleXMode,
  overlayConfig,
  onToggleOverlay,
  onQuickCleanRam,
  onUpdateGameConfig,
  onAddGame,
}) => {
  const [selectedGameId, setSelectedGameId] = useState<string>(games[0]?.id || 'game-1');
  const [activeSimulatorGame, setActiveSimulatorGame] = useState<GameItem | null>(null);
  const [showAddGameModal, setShowAddGameModal] = useState(false);
  const [newGameTitle, setNewGameTitle] = useState('');
  const [newGamePackage, setNewGamePackage] = useState('');
  const [newGameGenre, setNewGameGenre] = useState('Action');

  const selectedGame = games.find((g) => g.id === selectedGameId) || games[0];

  const handleLaunchGame = (game: GameItem) => {
    sounds.playXModeActivate();
    // Ensure overlay is active so user sees real-time CPU/GPU/FPS overlay during gameplay!
    if (!overlayConfig.isEnabled) {
      onToggleOverlay();
    }
    setActiveSimulatorGame(game);
  };

  const handleCreateGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGameTitle.trim()) return;
    onAddGame({
      title: newGameTitle.trim(),
      packageName: newGamePackage.trim() || `com.game.${newGameTitle.toLowerCase().replace(/\s+/g, '')}`,
      genre: newGameGenre,
      coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop',
      targetFps: 120,
      resolutionScalePercent: 100,
      touchSensitivity: 9,
      audioEnhanced: true,
      networkAntiJitter: true,
      bypassCharging: true,
      blockCallsAndNotifications: true,
    });
    setNewGameTitle('');
    setNewGamePackage('');
    setShowAddGameModal(false);
    sounds.playClick();
  };

  return (
    <div className="space-y-6">
      {/* 1. ROG ARMOURY CRATE HEADER & X-MODE CONSOLE */}
      <div className="bg-gradient-to-r from-[#17090b] via-[#0e121a] to-[#07090c] border border-red-900/60 rounded-2xl p-5 relative overflow-hidden clip-corner-both">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-xs font-chakra font-bold tracking-widest text-red-500 mb-1">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              <span>REPUBLIC OF GAMERS • GAME SPACE ARMOURY CRATE</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-chakra font-black text-white tracking-wider flex items-center gap-2">
              GAME SPACE <span className="text-[#ff1a35]">ROG</span>
            </h2>
            <p className="text-xs text-slate-400 font-rajdhani mt-1 max-w-xl">
              Pusat komando gaming mobile. Konfigurasi X-Mode, profil FPS per-game, bypass charging, audio radar, serta
              floating overlay statistik performa CPU &amp; GPU real-time.
            </p>
          </div>

          {/* Master X-Mode Switch */}
          <div className="flex items-center space-x-3 bg-[#0a0d13] p-2.5 rounded-2xl border border-[#20293a]">
            <div className="text-right">
              <div className="text-xs font-chakra font-bold text-white tracking-wider">
                X-MODE OVERCLOCK
              </div>
              <div className="text-[10px] font-mono-code text-slate-400">
                {xModeActive ? '3.3GHz Prime • 1GHz GPU' : 'Mode Hemat / Siaga'}
              </div>
            </div>

            <button
              onClick={() => {
                onToggleXMode();
              }}
              className={`px-4 py-2.5 rounded-xl font-chakra font-bold text-xs uppercase flex items-center space-x-2 transition-all ${
                xModeActive
                  ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white glow-red border border-red-400 animate-pulse'
                  : 'bg-[#151c27] text-slate-400 hover:text-white border border-[#263347]'
              }`}
            >
              <Flame className={`w-4 h-4 ${xModeActive ? 'text-amber-300' : 'text-slate-500'}`} />
              <span>{xModeActive ? 'X-MODE ON' : 'AKTIFKAN'}</span>
            </button>
          </div>
        </div>

        {/* Real-time mini gaming banner stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-[#231a20]">
          <div className="bg-[#121620]/90 p-2.5 rounded-xl border border-[#222c3d] flex items-center justify-between">
            <span className="text-xs font-chakra text-slate-400">CURRENT FPS</span>
            <span className="text-lg font-chakra font-black text-cyan-400 text-glow-cyan">{Math.round(telemetry.fps)}</span>
          </div>

          <div className="bg-[#121620]/90 p-2.5 rounded-xl border border-[#222c3d] flex items-center justify-between">
            <span className="text-xs font-chakra text-slate-400">CPU LOAD</span>
            <span className="text-lg font-chakra font-black text-white">{Math.round(telemetry.cpuUsagePercent)}%</span>
          </div>

          <div className="bg-[#121620]/90 p-2.5 rounded-xl border border-[#222c3d] flex items-center justify-between">
            <span className="text-xs font-chakra text-slate-400">GPU ADRENO</span>
            <span className="text-lg font-chakra font-black text-amber-400">{Math.round(telemetry.gpuUsagePercent)}%</span>
          </div>

          <div className="bg-[#121620]/90 p-2.5 rounded-xl border border-[#222c3d] flex items-center justify-between">
            <span className="text-xs font-chakra text-slate-400">THERMAL</span>
            <span className={`text-lg font-chakra font-black ${
              telemetry.batteryTempC > 40 ? 'text-red-400' : 'text-emerald-400'
            }`}>
              {telemetry.batteryTempC.toFixed(1)}°C
            </span>
          </div>
        </div>
      </div>

      {/* 2. GAME LIBRARY CAROUSEL / SELECTOR */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Gamepad2 className="w-4 h-4 text-cyan-400" />
            <h3 className="font-chakra font-bold text-sm tracking-wider text-white uppercase">
              DAFTAR GAME TERINSTAL ({games.length})
            </h3>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              setShowAddGameModal(true);
            }}
            className="px-3 py-1 bg-[#141b27] hover:bg-[#1f2838] border border-[#232d3d] hover:border-cyan-500/60 rounded-xl text-xs font-chakra font-bold text-cyan-400 flex items-center space-x-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>TAMBAH GAME / APK</span>
          </button>
        </div>

        {/* Game Horizontal Scroll Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {games.map((game) => {
            const isSelected = game.id === selectedGameId;
            return (
              <div
                key={game.id}
                onClick={() => {
                  sounds.playClick();
                  setSelectedGameId(game.id);
                }}
                className={`relative group rounded-xl overflow-hidden cursor-pointer border transition-all duration-300 ${
                  isSelected
                    ? 'border-red-500 shadow-lg shadow-red-950/60 scale-[1.02]'
                    : 'border-[#20293a] opacity-75 hover:opacity-100 hover:border-slate-600'
                }`}
              >
                {/* Background Cover */}
                <div className="h-28 w-full relative overflow-hidden bg-black">
                  <img
                    src={game.coverImage}
                    alt={game.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0d14] via-[#0a0d14]/40 to-transparent"></div>
                  
                  {/* Target FPS Badge */}
                  <span className="absolute top-2 right-2 text-[10px] px-1.5 py-0.5 rounded font-mono-code font-bold bg-black/70 text-cyan-400 border border-cyan-800/60">
                    {game.targetFps} FPS
                  </span>
                </div>

                {/* Info Title */}
                <div className="p-2 bg-[#0d1117]">
                  <div className="text-xs font-chakra font-bold text-white truncate" title={game.title}>
                    {game.title}
                  </div>
                  <div className="text-[10px] text-slate-400 font-rajdhani truncate">{game.genre}</div>
                </div>

                {/* Selected Indicator Bar */}
                {isSelected && (
                  <div className="h-1 w-full bg-red-500 shadow-[0_0_8px_#ff1a35]"></div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. SELECTED GAME TUNING PANEL (PER-GAME PROFILE) */}
      {selectedGame && (
        <div className="bg-[#0d1117] border border-[#232d3d] rounded-2xl p-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-4 border-b border-[#1b2330] gap-4">
            <div className="flex items-center space-x-3.5">
              <div className="w-14 h-14 rounded-xl overflow-hidden border border-[#2a3649] shrink-0">
                <img src={selectedGame.coverImage} alt={selectedGame.title} className="w-full h-full object-cover" />
              </div>
              <div>
                <span className="text-[10px] px-2 py-0.5 bg-red-950/80 text-red-400 rounded font-mono-code border border-red-800/40 uppercase">
                  {selectedGame.genre}
                </span>
                <h3 className="text-xl font-chakra font-bold text-white mt-0.5">{selectedGame.title}</h3>
                <div className="text-xs text-slate-400 font-mono-code flex items-center space-x-3 mt-0.5">
                  <span>{selectedGame.packageName}</span>
                  <span>•</span>
                  <span>Waktu Main: {selectedGame.playTimeHours} jam</span>
                </div>
              </div>
            </div>

            {/* Launch Game Button with Floating Overlay */}
            <div className="flex items-center space-x-2.5">
              <button
                onClick={() => handleLaunchGame(selectedGame)}
                className="px-6 py-3 bg-gradient-to-r from-red-600 via-[#ff1a35] to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-chakra font-bold text-sm tracking-wider rounded-xl shadow-xl shadow-red-950/70 glow-red-sm flex items-center space-x-2 transition-all active:scale-95"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>MAIN SEKARANG + OVERLAY</span>
              </button>
            </div>
          </div>

          {/* Tuning Options Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
            {/* Target FPS Selector */}
            <div className="bg-[#121722] p-3.5 rounded-xl border border-[#20293a] space-y-2">
              <div className="flex items-center justify-between text-xs font-chakra">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" /> TARGET FRAME RATE
                </span>
                <span className="text-cyan-400 font-mono-code font-bold">{selectedGame.targetFps} FPS</span>
              </div>
              <p className="text-[11px] text-slate-400 font-rajdhani">Kunci frame rate layar &amp; scheduler game</p>
              <div className="grid grid-cols-5 gap-1 pt-1">
                {([60, 90, 120, 144, 165] as const).map((fps) => (
                  <button
                    key={fps}
                    onClick={() => {
                      sounds.playClick();
                      onUpdateGameConfig(selectedGame.id, { targetFps: fps });
                    }}
                    className={`py-1.5 text-xs font-mono-code font-bold rounded-lg border transition-all ${
                      selectedGame.targetFps === fps
                        ? 'bg-cyan-500 text-black border-cyan-400 shadow'
                        : 'bg-[#151c27] border-[#222d3e] text-slate-400 hover:text-white'
                    }`}
                  >
                    {fps}
                  </button>
                ))}
              </div>
            </div>

            {/* Touch Sensitivity */}
            <div className="bg-[#121722] p-3.5 rounded-xl border border-[#20293a] space-y-2">
              <div className="flex items-center justify-between text-xs font-chakra">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Crosshair className="w-3.5 h-3.5 text-red-400" /> SENSITIVITAS SENTUHAN
                </span>
                <span className="text-red-400 font-mono-code font-bold">{selectedGame.touchSensitivity}/10</span>
              </div>
              <p className="text-[11px] text-slate-400 font-rajdhani">Responsivitas sampling digitizer 720Hz</p>
              <input
                type="range"
                min="1"
                max="10"
                value={selectedGame.touchSensitivity}
                onChange={(e) => {
                  onUpdateGameConfig(selectedGame.id, { touchSensitivity: Number(e.target.value) });
                }}
                className="w-full accent-red-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono-code">
                <span>Presisi Lambat (1)</span>
                <span>Normal (5)</span>
                <span>Instan Ekstrem (10)</span>
              </div>
            </div>

            {/* Resolution Scaler */}
            <div className="bg-[#121722] p-3.5 rounded-xl border border-[#20293a] space-y-2">
              <div className="flex items-center justify-between text-xs font-chakra">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-amber-400" /> RESOLUTION SCALER
                </span>
                <span className="text-amber-400 font-mono-code font-bold">{selectedGame.resolutionScalePercent}%</span>
              </div>
              <p className="text-[11px] text-slate-400 font-rajdhani">Skala render internal untuk GPU load optimal</p>
              <div className="grid grid-cols-4 gap-1 pt-1">
                {[80, 90, 95, 100].map((res) => (
                  <button
                    key={res}
                    onClick={() => {
                      sounds.playClick();
                      onUpdateGameConfig(selectedGame.id, { resolutionScalePercent: res });
                    }}
                    className={`py-1.5 text-xs font-mono-code font-bold rounded-lg border transition-all ${
                      selectedGame.resolutionScalePercent === res
                        ? 'bg-amber-500 text-black border-amber-400 shadow'
                        : 'bg-[#151c27] border-[#222d3e] text-slate-400 hover:text-white'
                    }`}
                  >
                    {res}%
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Toggle Toggles for Game Profile */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-4 border-t border-[#1d2533]">
            {/* Bypass Charging */}
            <div className="p-3 bg-[#121722] rounded-xl border border-[#20293a] flex items-center justify-between">
              <div>
                <span className="text-xs font-chakra font-bold text-white flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-emerald-400" /> Bypass Charging
                </span>
                <p className="text-[10px] text-slate-400 font-rajdhani">Nol panas pengisian baterai</p>
              </div>
              <input
                type="checkbox"
                checked={selectedGame.bypassCharging}
                onChange={(e) => onUpdateGameConfig(selectedGame.id, { bypassCharging: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 cursor-pointer"
              />
            </div>

            {/* Block Notifications */}
            <div className="p-3 bg-[#121722] rounded-xl border border-[#20293a] flex items-center justify-between">
              <div>
                <span className="text-xs font-chakra font-bold text-white flex items-center gap-1">
                  <BellOff className="w-3.5 h-3.5 text-amber-400" /> Blokir Notifikasi
                </span>
                <p className="text-[10px] text-slate-400 font-rajdhani">Tanpa gangguan telepon/WA</p>
              </div>
              <input
                type="checkbox"
                checked={selectedGame.blockCallsAndNotifications}
                onChange={(e) => onUpdateGameConfig(selectedGame.id, { blockCallsAndNotifications: e.target.checked })}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Audio Enhanced */}
            <div className="p-3 bg-[#121722] rounded-xl border border-[#20293a] flex items-center justify-between">
              <div>
                <span className="text-xs font-chakra font-bold text-white flex items-center gap-1">
                  <Headphones className="w-3.5 h-3.5 text-cyan-400" /> SonicRadar 3D Audio
                </span>
                <p className="text-[10px] text-slate-400 font-rajdhani">Peningkatan langkah kaki musuh</p>
              </div>
              <input
                type="checkbox"
                checked={selectedGame.audioEnhanced}
                onChange={(e) => onUpdateGameConfig(selectedGame.id, { audioEnhanced: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Network Anti-Jitter */}
            <div className="p-3 bg-[#121722] rounded-xl border border-[#20293a] flex items-center justify-between">
              <div>
                <span className="text-xs font-chakra font-bold text-white flex items-center gap-1">
                  <Wifi className="w-3.5 h-3.5 text-blue-400" /> Network Anti-Jitter
                </span>
                <p className="text-[10px] text-slate-400 font-rajdhani">Ping rendah stabil 15-25ms</p>
              </div>
              <input
                type="checkbox"
                checked={selectedGame.networkAntiJitter}
                onChange={(e) => onUpdateGameConfig(selectedGame.id, { networkAntiJitter: e.target.checked })}
                className="w-4 h-4 accent-blue-500 cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* 4. INTERACTIVE GAME SIMULATOR VIEWPORT (When a game is launched) */}
      {activeSimulatorGame && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col">
          {/* Top In-Game Bar */}
          <div className="bg-[#07090c] border-b border-[#232d3d] px-4 py-2 flex items-center justify-between text-xs font-chakra">
            <div className="flex items-center space-x-3">
              <span className="px-2 py-0.5 bg-red-950 text-red-400 border border-red-700/60 rounded font-bold uppercase">
                IN-GAME SIMULATOR
              </span>
              <span className="text-white font-bold text-sm">{activeSimulatorGame.title}</span>
              <span className="text-slate-400 font-mono-code hidden sm:inline">Target: {activeSimulatorGame.targetFps} FPS</span>
            </div>

            <div className="flex items-center space-x-3">
              <span className="text-[11px] text-emerald-400 font-mono-code flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                OVERLAY AKTIF DI LAYAR
              </span>

              <button
                onClick={() => {
                  sounds.playClick();
                  setActiveSimulatorGame(null);
                }}
                className="px-3 py-1 bg-red-900/60 hover:bg-red-800 text-white rounded-lg font-bold border border-red-600 transition-colors flex items-center space-x-1"
              >
                <X className="w-3.5 h-3.5" />
                <span>KELUAR DARI GAME</span>
              </button>
            </div>
          </div>

          {/* Simulated Game Arena with moving 3D cyber grid & game canvas visual */}
          <div className="flex-1 relative overflow-hidden bg-[#0a0d14] flex items-center justify-center bg-cyber-grid">
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60 pointer-events-none"></div>

            {/* Game Canvas Graphic Preview */}
            <div className="text-center relative z-10 max-w-lg p-6 bg-black/60 backdrop-blur-md rounded-2xl border border-red-900/40 clip-corner-both">
              <div className="w-16 h-16 mx-auto mb-3 rounded-2xl overflow-hidden border-2 border-red-500 shadow-xl glow-red-sm">
                <img src={activeSimulatorGame.coverImage} alt={activeSimulatorGame.title} className="w-full h-full object-cover" />
              </div>
              <h4 className="text-2xl font-chakra font-black text-white">{activeSimulatorGame.title}</h4>
              <p className="text-xs text-slate-300 font-rajdhani mt-1">
                Sesi game sedang berjalan. Perhatikan widget <span className="text-cyan-400 font-bold">Floating Overlay</span> di sudut layar.
                Anda dapat menggeser/drag overlay ke mana saja, mengecek FPS 165Hz, memantau penggunaan CPU/GPU, dan membersihkan RAM secara langsung!
              </p>

              {/* In-Game Actions */}
              <div className="flex items-center justify-center space-x-3 mt-4">
                <button
                  onClick={() => {
                    sounds.playBoostClean();
                    onQuickCleanRam();
                  }}
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-black font-chakra font-bold text-xs rounded-xl flex items-center space-x-1.5 shadow-lg shadow-cyan-950/60"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>CLEAN RAM DI TENGAH GAME</span>
                </button>
                <button
                  onClick={onToggleXMode}
                  className="px-4 py-2 bg-red-950/80 border border-red-600 hover:bg-red-900 text-red-300 font-chakra font-bold text-xs rounded-xl flex items-center space-x-1.5"
                >
                  <Flame className="w-3.5 h-3.5 text-red-400" />
                  <span>X-MODE BOOST</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. ADD CUSTOM GAME MODAL */}
      {showAddGameModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0d1117] border border-[#232d3d] rounded-2xl p-5 clip-corner-both glow-cyan-sm">
            <div className="flex items-center justify-between pb-3 border-b border-[#1d2533]">
              <div className="flex items-center space-x-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <h3 className="font-chakra font-bold text-sm tracking-wider text-white">
                  TAMBAHKAN GAME KE ROG GAME SPACE
                </h3>
              </div>
              <button
                onClick={() => setShowAddGameModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateGame} className="mt-4 space-y-3.5 text-xs font-chakra">
              <div>
                <label className="text-slate-300 block mb-1">Judul Game:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. EA FC Mobile, eFootball, dll."
                  value={newGameTitle}
                  onChange={(e) => setNewGameTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-[#141b27] border border-[#232d3d] rounded-xl text-white focus:outline-none focus:border-cyan-500 font-rajdhani text-sm"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Nama Package APK (Opsional):</label>
                <input
                  type="text"
                  placeholder="com.ea.gp.fifamobile"
                  value={newGamePackage}
                  onChange={(e) => setNewGamePackage(e.target.value)}
                  className="w-full px-3 py-2 bg-[#141b27] border border-[#232d3d] rounded-xl text-white focus:outline-none focus:border-cyan-500 font-mono-code text-xs"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Genre:</label>
                <select
                  value={newGameGenre}
                  onChange={(e) => setNewGameGenre(e.target.value)}
                  className="w-full px-3 py-2 bg-[#141b27] border border-[#232d3d] rounded-xl text-white focus:outline-none focus:border-cyan-500 font-rajdhani text-sm"
                >
                  <option value="Action">Action / Shooter</option>
                  <option value="MOBA">MOBA 5v5</option>
                  <option value="Battle Royale">Battle Royale</option>
                  <option value="Racing">Racing / Sports</option>
                  <option value="RPG">RPG / Open-World</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddGameModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold shadow-md shadow-cyan-950/60"
                >
                  Tambahkan Game
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
