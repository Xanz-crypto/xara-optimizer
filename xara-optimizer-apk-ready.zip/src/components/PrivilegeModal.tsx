import React from 'react';
import { 
  ShieldCheck, 
  Terminal, 
  Cpu, 
  CheckCircle2, 
  X, 
  Smartphone, 
  Wifi, 
  HelpCircle,
  Copy,
  ExternalLink,
  Flame
} from 'lucide-react';
import { PrivilegeMode, DeviceHardware } from '../types/optimizer';
import { sounds } from '../utils/soundEffects';

interface PrivilegeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentMode: PrivilegeMode;
  onSelectMode: (mode: PrivilegeMode) => void;
  device: DeviceHardware;
}

export const PrivilegeModal: React.FC<PrivilegeModalProps> = ({
  isOpen,
  onClose,
  currentMode,
  onSelectMode,
  device,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-[#090d14] border border-[#232d3d] rounded-2xl p-6 shadow-2xl clip-corner-both">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#1b2332]">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-red-950/80 border border-red-800/60 rounded-xl text-red-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-chakra font-bold text-base tracking-wider text-white">
                METODE HAK AKSES SISTEM (ROOT &amp; SHIZUKU)
              </h3>
              <p className="text-xs text-slate-400 font-rajdhani">
                Pilih metode eksekusi perintah tuning kernel, bypass charging &amp; kill background apps
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Cards */}
        <div className="mt-5 space-y-3">
          {/* 1. ROOT MODE */}
          <div
            onClick={() => {
              sounds.playClick();
              onSelectMode('root');
            }}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              currentMode === 'root'
                ? 'bg-gradient-to-r from-red-950/80 via-[#181116] to-[#0c1017] border-red-500 shadow-lg shadow-red-950/50'
                : 'bg-[#10151f] border-[#1e2738] hover:border-slate-600'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="p-1.5 rounded-lg bg-red-900/40 text-red-400 font-bold font-chakra text-xs">
                  SU
                </span>
                <div>
                  <h4 className="font-chakra font-bold text-sm text-white flex items-center gap-2">
                    ROOT (Magisk / KernelSU / APatch)
                    {currentMode === 'root' && (
                      <span className="text-[10px] px-1.5 py-0.2 bg-red-600 text-white rounded font-mono-code">
                        TERPILIH
                      </span>
                    )}
                  </h4>
                  <p className="text-xs text-slate-300 font-rajdhani mt-0.5">
                    Akses sysfs level kernel penuh. Ubah governor CPU/GPU, bypass charging, stop thermal throttling,
                    swappiness, drop caches memori, dan overclocking.
                  </p>
                </div>
              </div>
              {currentMode === 'root' && <CheckCircle2 className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />}
            </div>

            <div className="mt-2.5 pt-2 border-t border-[#1d2636] flex items-center space-x-3 text-[11px] font-mono-code text-slate-400">
              <span className="text-emerald-400 font-semibold">UID 0 (root)</span>
              <span>•</span>
              <span>SELinux: Permissive</span>
              <span>•</span>
              <span className="text-cyan-400">Busybox: Ready</span>
            </div>
          </div>

          {/* 2. SHIZUKU MODE */}
          <div
            onClick={() => {
              sounds.playClick();
              onSelectMode('shizuku');
            }}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              currentMode === 'shizuku'
                ? 'bg-gradient-to-r from-cyan-950/80 via-[#0d1c24] to-[#091118] border-cyan-400 shadow-lg shadow-cyan-950/50'
                : 'bg-[#10151f] border-[#1e2738] hover:border-slate-600'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="p-1.5 rounded-lg bg-cyan-900/40 text-cyan-400 font-bold font-chakra text-xs">
                  RISH
                </span>
                <div>
                  <h4 className="font-chakra font-bold text-sm text-white flex items-center gap-2">
                    SHIZUKU (Wireless ADB / rish v3.2)
                    {currentMode === 'shizuku' && (
                      <span className="text-[10px] px-1.5 py-0.2 bg-cyan-500 text-black font-extrabold rounded font-mono-code">
                        TERPILIH
                      </span>
                    )}
                  </h4>
                  <p className="text-xs text-slate-300 font-rajdhani mt-0.5">
                    Cocok untuk HP NON-ROOT! Memanfaatkan Shizuku IPC service untuk force-stop background apps,
                    mengubah refresh rate layar (60-165Hz), dan optimasi SurfaceFlinger.
                  </p>
                </div>
              </div>
              {currentMode === 'shizuku' && <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />}
            </div>

            <div className="mt-2.5 pt-2 border-t border-[#1d2636] flex items-center space-x-3 text-[11px] font-mono-code text-slate-400">
              <span className="text-cyan-300 font-semibold">IPC Port: 5555</span>
              <span>•</span>
              <span>API Level: 13.5</span>
              <span>•</span>
              <span className="text-emerald-400">Pairing: Authorized</span>
            </div>
          </div>

          {/* 3. STANDARD ADB MODE */}
          <div
            onClick={() => {
              sounds.playClick();
              onSelectMode('standard');
            }}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              currentMode === 'standard'
                ? 'bg-[#161c28] border-slate-400 text-white'
                : 'bg-[#10151f] border-[#1e2738] hover:border-slate-600'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="p-1.5 rounded-lg bg-slate-800 text-slate-300 font-bold font-chakra text-xs">
                  ADB
                </span>
                <div>
                  <h4 className="font-chakra font-bold text-sm text-white">STANDARD / SIMULASI</h4>
                  <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
                    Mode simulasi aman tanpa modifikasi sistem langsung. Menghasilkan script ekspor yang dapat Anda jalankan via PC.
                  </p>
                </div>
              </div>
              {currentMode === 'standard' && <CheckCircle2 className="w-5 h-5 text-slate-300 shrink-0 mt-0.5" />}
            </div>
          </div>
        </div>

        {/* Shizuku Pairing Quick Tips */}
        <div className="mt-4 p-3.5 bg-[#0e141f] border border-[#1f2b3e] rounded-xl text-xs text-slate-300 space-y-1.5">
          <div className="font-chakra font-bold text-cyan-400 flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5" /> Cara Mengaktifkan Shizuku Tanpa PC:
          </div>
          <ol className="list-decimal pl-4 space-y-1 font-rajdhani text-xs text-slate-400">
            <li>Aktifkan <b>Opsi Pengembang (Developer Options)</b> di pengaturan HP.</li>
            <li>Buka <b>Wireless Debugging (Debugging Nirkabel)</b> dan sambungkan ke Wi-Fi.</li>
            <li>Buka aplikasi Shizuku, pilih <i>Pairing</i> dengan memasukkan 6-digit kode pairing.</li>
            <li>Pilih <i>Start</i> di Shizuku. Xara Optimizer akan langsung mendeteksi izin <code>rish</code>.</li>
          </ol>
        </div>

        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-chakra font-bold text-xs rounded-xl shadow-lg shadow-red-950/60"
          >
            SIMPAN &amp; TERAPKAN HAK AKSES
          </button>
        </div>
      </div>
    </div>
  );
};
