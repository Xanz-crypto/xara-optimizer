import React, { useState, useRef, useEffect } from 'react';
import { 
  Terminal, 
  X, 
  Download, 
  Copy, 
  Check, 
  Trash2, 
  Play, 
  ShieldCheck,
  Send,
  HelpCircle
} from 'lucide-react';
import { TerminalLog, KernelSettings, BatteryOptSettings, PrivilegeMode } from '../types/optimizer';
import { generateShellScript } from '../data/mockSystem';
import { sounds } from '../utils/soundEffects';

interface TerminalDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  logs: TerminalLog[];
  onClearLogs: () => void;
  onExecuteCommand: (cmd: string) => void;
  kernelSettings: KernelSettings;
  batterySettings: BatteryOptSettings;
  privilegeMode: PrivilegeMode;
}

export const TerminalDrawer: React.FC<TerminalDrawerProps> = ({
  isOpen,
  onClose,
  logs,
  onClearLogs,
  onExecuteCommand,
  kernelSettings,
  batterySettings,
  privilegeMode,
}) => {
  const [inputCmd, setInputCmd] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCmd.trim()) return;
    sounds.playClick();
    onExecuteCommand(inputCmd.trim());
    setInputCmd('');
  };

  const handleCopyScript = () => {
    const script = generateShellScript(kernelSettings, batterySettings, privilegeMode === 'shizuku' ? 'shizuku' : 'root');
    navigator.clipboard.writeText(script);
    setCopiedScript(true);
    sounds.playClick();
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const handleDownloadScript = () => {
    sounds.playClick();
    const script = generateShellScript(kernelSettings, batterySettings, privilegeMode === 'shizuku' ? 'shizuku' : 'root');
    const blob = new Blob([script], { type: 'text/x-shellscript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `xara_rog_tune_${privilegeMode}.sh`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-2xl h-full bg-[#07090d] border-l border-[#20293a] flex flex-col shadow-2xl">
        {/* Terminal Header */}
        <div className="bg-[#0b0f17] border-b border-[#1b2332] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-amber-500"></div>
            <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
            <span className="text-xs font-mono-code font-bold text-white ml-2 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              xara-shell@{privilegeMode === 'root' ? 'root_magisk' : 'shizuku_rish'}:~#
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyScript}
              className="px-2.5 py-1 bg-[#131b27] hover:bg-[#1a2536] border border-[#232d3e] text-slate-300 rounded text-xs font-chakra flex items-center space-x-1"
              title="Salin Shell Script ke Clipboard"
            >
              {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedScript ? 'Tersalin' : 'Copy .sh'}</span>
            </button>

            <button
              onClick={handleDownloadScript}
              className="px-2.5 py-1 bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-800/60 text-cyan-400 rounded text-xs font-chakra flex items-center space-x-1"
              title="Download Script Shell xara_rog_tune.sh"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export .sh</span>
            </button>

            <button
              onClick={onClearLogs}
              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded"
              title="Bersihkan Log Terminal"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onClose}
              className="p-1 hover:bg-red-900/40 text-slate-400 hover:text-red-400 rounded"
              title="Tutup Terminal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Commands Bar */}
        <div className="bg-[#0e131d] px-4 py-2 border-b border-[#1b2332] flex items-center space-x-2 overflow-x-auto text-xs font-mono-code">
          <span className="text-[10px] text-slate-400 font-chakra uppercase shrink-0">Quick Cmd:</span>
          {[
            'echo performance > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor',
            'echo 3 > /proc/sys/vm/drop_caches',
            'cat /sys/class/thermal/thermal_zone0/temp',
            'settings put system min_refresh_rate 165',
            'am force-stop com.zhiliaoapp.musically',
          ].map((cmd, i) => (
            <button
              key={i}
              onClick={() => {
                sounds.playClick();
                onExecuteCommand(cmd);
              }}
              className="px-2 py-0.5 bg-[#151c27] hover:bg-[#1f2838] border border-[#232f42] rounded text-slate-300 hover:text-cyan-300 text-[11px] whitespace-nowrap"
            >
              {cmd.split('>')[0].substring(0, 24)}...
            </button>
          ))}
        </div>

        {/* Terminal Screen Console */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 font-mono-code text-xs bg-[#07090d]">
          <div className="p-3 bg-[#0d121c] border border-[#1f293a] rounded-xl text-slate-400 space-y-1">
            <div className="text-emerald-400 font-bold">
              [XARA OPTIMIZER] Kernel Shell Bridge Environment v4.2
            </div>
            <div>Mode Hak Akses: <span className="text-white font-bold">{privilegeMode.toUpperCase()}</span></div>
            <div>SELinux: <span className="text-cyan-400">Permissive</span> • Android API: <span className="text-white">34 (Android 14)</span></div>
            <div className="text-[11px] text-slate-500">
              Ketik perintah shell di bawah atau klik tombol quick command untuk memodifikasi sysfs/kernel secara langsung.
            </div>
          </div>

          {logs.map((log) => (
            <div key={log.id} className="space-y-0.5">
              <div className="flex items-center space-x-2 text-[11px]">
                <span className="text-slate-500">{log.timestamp}</span>
                <span className={`px-1 rounded text-[10px] font-bold ${
                  log.mode === 'ROOT' ? 'bg-red-950 text-red-400' : 'bg-cyan-950 text-cyan-400'
                }`}>
                  [{log.mode}]
                </span>
                <span className="text-cyan-300">$ {log.command}</span>
              </div>
              <div className={`pl-4 text-[11px] whitespace-pre-wrap leading-relaxed ${
                log.status === 'success' ? 'text-slate-300' : log.status === 'warn' ? 'text-amber-300' : 'text-red-400'
              }`}>
                {log.output}
              </div>
            </div>
          ))}
          <div ref={logEndRef} />
        </div>

        {/* Command Input Form */}
        <form onSubmit={handleSubmit} className="p-3 bg-[#0a0d14] border-t border-[#1b2332] flex items-center space-x-2">
          <span className="text-emerald-400 font-mono-code font-bold text-sm pl-1">$</span>
          <input
            type="text"
            value={inputCmd}
            onChange={(e) => setInputCmd(e.target.value)}
            placeholder="Ketik perintah su/rish (contoh: id, cat /proc/version, am kill-all)..."
            className="flex-1 bg-[#121722] border border-[#232d3d] rounded-xl px-3 py-2 text-xs font-mono-code text-white focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-black font-chakra font-bold text-xs rounded-xl flex items-center space-x-1"
          >
            <Send className="w-3.5 h-3.5" />
            <span>KIRIM</span>
          </button>
        </form>
      </div>
    </div>
  );
};
