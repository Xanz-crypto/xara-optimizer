import React from 'react';
import { 
  Flame, 
  Gamepad2, 
  Cpu, 
  Terminal, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  Zap,
  Activity,
  Maximize2
} from 'lucide-react';
import { PrivilegeMode, LiveTelemetry, OverlayConfig } from '../types/optimizer';
import { sounds } from '../utils/soundEffects';

interface HeaderNavProps {
  activeTab: 'tuner' | 'gamespace';
  onTabChange: (tab: 'tuner' | 'gamespace') => void;
  privilegeMode: PrivilegeMode;
  onPrivilegeClick: () => void;
  telemetry: LiveTelemetry;
  onOpenTerminal: () => void;
  overlayConfig: OverlayConfig;
  onToggleOverlay: () => void;
  soundMuted: boolean;
  onToggleSound: () => void;
  xModeActive: boolean;
  onToggleXMode: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeTab,
  onTabChange,
  privilegeMode,
  onPrivilegeClick,
  telemetry,
  onOpenTerminal,
  overlayConfig,
  onToggleOverlay,
  soundMuted,
  onToggleSound,
  xModeActive,
  onToggleXMode,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#07090c]/90 backdrop-blur-md border-b border-[#1d2533]">
      {/* Top micro bar for privilege and thermal status */}
      <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center justify-between text-xs border-b border-[#141a24] text-slate-400">
        <div className="flex items-center space-x-3">
          {/* Privilege badge button */}
          <button
            onClick={() => {
              sounds.playClick();
              onPrivilegeClick();
            }}
            className={`flex items-center space-x-1.5 px-2.5 py-0.5 rounded text-[11px] font-chakra font-semibold tracking-wider transition-all ${
              privilegeMode === 'root'
                ? 'bg-red-950/80 text-red-400 border border-red-800/80 hover:bg-red-900/60'
                : privilegeMode === 'shizuku'
                ? 'bg-cyan-950/80 text-cyan-400 border border-cyan-800/80 hover:bg-cyan-900/60'
                : 'bg-slate-800/80 text-slate-300 border border-slate-700 hover:bg-slate-700/60'
            }`}
            title="Klik untuk info hak akses Root / Shizuku"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="uppercase">
              {privilegeMode === 'root'
                ? '⚡ ROOT: KERNELSU ACTIVE'
                : privilegeMode === 'shizuku'
                ? '🛡️ SHIZUKU: RISH v3.2 CONNECTED'
                : '⚠️ STANDARD ACCESS'}
            </span>
          </button>

          <span className="hidden sm:inline-block text-[#323f54]">|</span>

          {/* Real-time SoC info */}
          <span className="hidden md:flex items-center space-x-1 font-mono-code text-[11px] text-slate-400">
            <span className="text-[#00f0ff]">Snapdragon 8 Gen 3</span>
            <span className="text-slate-600">@</span>
            <span>{telemetry.cpuClusters[2]?.currentFreqMhz || 3187} MHz</span>
          </span>
        </div>

        {/* Live thermal, refresh rate & sound toggle */}
        <div className="flex items-center space-x-3">
          {/* Temperature status */}
          <div className="flex items-center space-x-1 font-mono-code text-[11px]">
            <span className="text-slate-500">BATT:</span>
            <span className={`font-semibold ${
              telemetry.batteryTempC > 40 ? 'text-red-400 animate-pulse' : telemetry.batteryTempC > 36 ? 'text-amber-400' : 'text-emerald-400'
            }`}>
              {telemetry.batteryTempC.toFixed(1)}°C
            </span>
          </div>

          <span className="text-[#323f54]">|</span>

          {/* Refresh rate */}
          <div className="flex items-center space-x-1 font-mono-code text-[11px]">
            <span className="text-slate-500">HZ:</span>
            <span className="text-cyan-400 font-semibold">{telemetry.activeRefreshRate}Hz</span>
          </div>

          <span className="text-[#323f54]">|</span>

          {/* Sound toggle button */}
          <button
            onClick={() => {
              onToggleSound();
              sounds.playClick();
            }}
            className="text-slate-400 hover:text-white transition-colors"
            title={soundMuted ? 'Nyalakan Efek Suara ROG' : 'Matikan Suara'}
          >
            {soundMuted ? <VolumeX className="w-3.5 h-3.5 text-slate-500" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div className="flex items-center space-x-3">
          <div className="relative group cursor-pointer" onClick={() => onTabChange('tuner')}>
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-chakra font-black text-lg transition-all duration-300 ${
              xModeActive 
                ? 'bg-gradient-to-br from-[#ff1a35] via-red-600 to-red-900 text-white glow-red animate-pulse-glow'
                : 'bg-[#151b24] text-red-500 border border-red-900/60'
            }`}>
              X
            </div>
            {xModeActive && (
              <span className="absolute -bottom-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h1 className="font-chakra font-bold text-base tracking-wider text-white flex items-center gap-1.5">
                XARA <span className="text-[#ff1a35]">OPTIMIZER</span>
              </h1>
              <span className="text-[10px] px-1.5 py-0.2 font-mono-code rounded bg-red-950/80 text-red-400 border border-red-800/40 uppercase">
                ROG v4.2
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-rajdhani font-semibold tracking-wider">
              KERNEL TUNER &amp; GAME SPACE ARMOURY CRATE
            </p>
          </div>
        </div>

        {/* Dual Home Tab Switcher (Central) */}
        <div className="flex items-center bg-[#0d121a] p-1 rounded-xl border border-[#232d3d]">
          <button
            onClick={() => {
              sounds.playClick();
              onTabChange('tuner');
            }}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-chakra font-bold transition-all ${
              activeTab === 'tuner'
                ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-lg shadow-red-950/60'
                : 'text-slate-400 hover:text-white hover:bg-[#161d28]'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="tracking-wider">SYSTEM TUNER</span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              onTabChange('gamespace');
            }}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-chakra font-bold transition-all relative ${
              activeTab === 'gamespace'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-extrabold shadow-lg shadow-cyan-950/60'
                : 'text-slate-400 hover:text-cyan-400 hover:bg-[#161d28]'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span className="tracking-wider">GAME SPACE ROG</span>
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
          </button>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center space-x-2">
          {/* X-Mode Turbo Boost Button */}
          <button
            onClick={() => {
              onToggleXMode();
            }}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 font-chakra text-xs font-bold tracking-wider transition-all ${
              xModeActive
                ? 'bg-red-600 hover:bg-red-700 text-white glow-red-sm border border-red-400/80 animate-pulse'
                : 'bg-[#151c27] hover:bg-[#1f2838] text-slate-300 border border-[#263347]'
            }`}
            title="Aktifkan Profil Overclock X-Mode ROG"
          >
            <Flame className={`w-3.5 h-3.5 ${xModeActive ? 'text-amber-300' : 'text-red-500'}`} />
            <span className="hidden sm:inline">X-MODE</span>
          </button>

          {/* Floating Performance Overlay Toggle */}
          <button
            onClick={() => {
              sounds.playToggle(!overlayConfig.isEnabled);
              onToggleOverlay();
            }}
            className={`px-2.5 py-1.5 rounded-lg flex items-center space-x-1.5 font-chakra text-xs font-semibold border transition-all ${
              overlayConfig.isEnabled
                ? 'bg-cyan-950/90 text-cyan-300 border-cyan-500 glow-cyan-sm'
                : 'bg-[#151c27] text-slate-400 border-[#232d3d] hover:text-white'
            }`}
            title="Aktifkan Floating Overlay Statistik Performa Real-Time"
          >
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">OVERLAY HUD</span>
          </button>

          {/* Terminal Logs Toggle */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenTerminal();
            }}
            className="p-1.5 rounded-lg bg-[#151c27] text-slate-400 hover:text-white border border-[#232d3d] hover:border-slate-600 transition-colors"
            title="Buka Terminal Shell Log (Root/Shizuku)"
          >
            <Terminal className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
