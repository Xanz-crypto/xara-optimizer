import React, { useState } from 'react';
import { 
  Flame, 
  Cpu, 
  Zap, 
  Sparkles, 
  Thermometer, 
  BatteryCharging, 
  Battery, 
  CheckCircle2, 
  AlertTriangle, 
  Sliders, 
  Layers, 
  Play, 
  RotateCcw, 
  RefreshCw, 
  Trash2, 
  ShieldAlert, 
  Smartphone,
  Gauge,
  Wifi,
  Radio,
  SlidersHorizontal,
  ChevronRight,
  Filter,
  Snowflake,
  Terminal
} from 'lucide-react';
import { 
  BackgroundApp, 
  BatteryOptSettings, 
  DeviceHardware, 
  KernelSettings, 
  LiveTelemetry, 
  PrivilegeMode 
} from '../types/optimizer';
import { sounds } from '../utils/soundEffects';

interface SystemTunerHomeProps {
  device: DeviceHardware;
  telemetry: LiveTelemetry;
  kernelSettings: KernelSettings;
  batterySettings: BatteryOptSettings;
  backgroundApps: BackgroundApp[];
  privilegeMode: PrivilegeMode;
  onUpdateKernel: (newSettings: Partial<KernelSettings>) => void;
  onUpdateBattery: (newSettings: Partial<BatteryOptSettings>) => void;
  onBoostRam: () => void;
  onKillApp: (appId: string) => void;
  onKillAllApps: () => void;
  onScanApps: () => void;
  isScanning: boolean;
  xModeActive: boolean;
  onToggleXMode: () => void;
  onOpenPrivilegeModal: () => void;
  onOpenTerminal: () => void;
}

export const SystemTunerHome: React.FC<SystemTunerHomeProps> = ({
  device,
  telemetry,
  kernelSettings,
  batterySettings,
  backgroundApps,
  privilegeMode,
  onUpdateKernel,
  onUpdateBattery,
  onBoostRam,
  onKillApp,
  onKillAllApps,
  onScanApps,
  isScanning,
  xModeActive,
  onToggleXMode,
  onOpenPrivilegeModal,
  onOpenTerminal,
}) => {
  const [activeKernelTab, setActiveKernelTab] = useState<'cpu' | 'gpu' | 'memory' | 'display' | 'thermal'>('cpu');
  const [appCategoryFilter, setAppCategoryFilter] = useState<'all' | 'social' | 'games' | 'bloatware' | 'media'>('all');
  const [boostAnimating, setBoostAnimating] = useState(false);

  const handleBoost = () => {
    sounds.playBoostClean();
    setBoostAnimating(true);
    onBoostRam();
    setTimeout(() => {
      setBoostAnimating(false);
    }, 1200);
  };

  const filteredApps = backgroundApps.filter((app) => {
    if (appCategoryFilter === 'all') return true;
    return app.category === appCategoryFilter;
  });

  const totalKillableRamMb = backgroundApps
    .filter((a) => !a.isKilled && !a.isWhitelisted)
    .reduce((sum, a) => sum + a.ramMb, 0);

  return (
    <div className="space-y-6">
      {/* 1. HERO SYSTEM STATUS & PERFORMANCE GAUGES */}
      <section className="bg-gradient-to-b from-[#111622] via-[#0d1219] to-[#07090c] border border-[#232d3d] rounded-2xl p-5 relative overflow-hidden clip-corner-both">
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-600/5 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20"></div>

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          {/* Status Label & Title */}
          <div>
            <div className="flex items-center space-x-2 text-xs font-chakra font-bold tracking-widest text-slate-400 mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>DEVICE OPTIMIZATION ENGINE</span>
              <span>•</span>
              <span className="text-[#ff1a35]">SNAPDRAGON 8 GEN 3</span>
            </div>

            <div className="flex items-baseline space-x-3">
              <h2 className="text-3xl sm:text-4xl font-chakra font-black text-white tracking-wider">
                {xModeActive ? (
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-amber-300">
                    X-MODE OVERCLOCK ACTIVE
                  </span>
                ) : (
                  <span>SYSTEM OPTIMIZED</span>
                )}
              </h2>
              <span className={`text-xs px-2 py-0.5 rounded font-mono-code border ${
                xModeActive 
                  ? 'bg-red-950/80 text-red-400 border-red-700/80 glow-red-sm animate-pulse' 
                  : 'bg-emerald-950/80 text-emerald-400 border-emerald-700/60'
              }`}>
                {xModeActive ? 'PERF EXTREME' : 'DYNAMIC BALANCED'}
              </span>
            </div>

            <p className="text-sm text-slate-400 font-rajdhani mt-1 max-w-xl">
              Kernel <span className="text-slate-200">{device.kernel.split('-')[0]}</span> dengan hak akses{' '}
              <button 
                onClick={onOpenPrivilegeModal}
                className="text-cyan-400 underline decoration-dotted font-semibold hover:text-cyan-300"
              >
                {privilegeMode === 'root' ? 'Root (su)' : privilegeMode === 'shizuku' ? 'Shizuku (rish)' : 'Standard ADB'}
              </button>
              . Suhu terkendali, FPS terkunci {telemetry.activeRefreshRate}Hz, pembersih memori aktif.
            </p>
          </div>

          {/* Quick 1-Tap Boost Button */}
          <div className="flex items-center space-x-3 w-full lg:w-auto">
            <button
              onClick={handleBoost}
              disabled={boostAnimating}
              className={`flex-1 lg:flex-initial px-6 py-4 rounded-xl font-chakra font-bold text-sm tracking-widest uppercase transition-all flex items-center justify-center space-x-2.5 ${
                boostAnimating
                  ? 'bg-gradient-to-r from-emerald-600 to-cyan-600 text-white animate-pulse'
                  : 'bg-gradient-to-r from-[#ff1a35] via-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white shadow-xl shadow-red-950/70 glow-red-sm active:scale-95'
              }`}
            >
              <Sparkles className={`w-5 h-5 ${boostAnimating ? 'animate-spin' : ''}`} />
              <span>{boostAnimating ? 'STABILIZING & CLEANING...' : '1-TAP BOOST & CLEAR RAM'}</span>
            </button>

            <button
              onClick={onToggleXMode}
              className={`p-4 rounded-xl border font-chakra font-bold text-xs transition-all flex flex-col items-center justify-center ${
                xModeActive
                  ? 'bg-red-600/30 text-red-400 border-red-500 glow-red-sm'
                  : 'bg-[#151b26] text-slate-400 border-[#232d3d] hover:text-white hover:bg-[#1a2332]'
              }`}
              title="Toggle ROG X-Mode"
            >
              <Flame className={`w-5 h-5 mb-0.5 ${xModeActive ? 'text-red-500' : 'text-slate-500'}`} />
              <span className="text-[10px]">X-MODE</span>
            </button>
          </div>
        </div>

        {/* Real-time Hardware Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 pt-5 border-t border-[#1d2533]">
          {/* CPU Card */}
          <div className="bg-[#121722]/80 border border-[#20293a] rounded-xl p-3.5 hover:border-cyan-500/40 transition-colors">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-chakra font-semibold flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-cyan-400" /> CPU USAGE
              </span>
              <span className="font-mono-code text-[11px] text-cyan-300 font-bold">{Math.round(telemetry.cpuUsagePercent)}%</span>
            </div>
            <div className="text-2xl font-chakra font-black text-white text-glow-cyan">
              {Math.round(telemetry.cpuUsagePercent)}<span className="text-sm font-normal text-slate-400">%</span>
            </div>
            <div className="w-full bg-[#080b10] h-1.5 rounded-full overflow-hidden mt-2">
              <div 
                style={{ width: `${telemetry.cpuUsagePercent}%` }} 
                className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-300"
              />
            </div>
            <div className="text-[10px] text-slate-400 font-mono-code mt-1.5 flex justify-between">
              <span>Gov: {kernelSettings.cpuGovernor}</span>
              <span className="text-slate-300">{telemetry.cpuClusters[2]?.currentFreqMhz}MHz</span>
            </div>
          </div>

          {/* GPU Card */}
          <div className="bg-[#121722]/80 border border-[#20293a] rounded-xl p-3.5 hover:border-amber-500/40 transition-colors">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-chakra font-semibold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" /> GPU CLOCK
              </span>
              <span className="font-mono-code text-[11px] text-amber-300 font-bold">{Math.round(telemetry.gpuUsagePercent)}%</span>
            </div>
            <div className="text-2xl font-chakra font-black text-white">
              {telemetry.gpuFreqMhz}<span className="text-sm font-normal text-slate-400">MHz</span>
            </div>
            <div className="w-full bg-[#080b10] h-1.5 rounded-full overflow-hidden mt-2">
              <div 
                style={{ width: `${telemetry.gpuUsagePercent}%` }} 
                className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-300"
              />
            </div>
            <div className="text-[10px] text-slate-400 font-mono-code mt-1.5 flex justify-between">
              <span>Adreno 750</span>
              <span className="text-amber-400">Boost: {kernelSettings.adrenoBoostLevel.toUpperCase()}</span>
            </div>
          </div>

          {/* RAM & ZRAM Card */}
          <div className="bg-[#121722]/80 border border-[#20293a] rounded-xl p-3.5 hover:border-purple-500/40 transition-colors">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-chakra font-semibold flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" /> RAM / ZRAM
              </span>
              <span className="font-mono-code text-[11px] text-purple-300 font-bold">
                {Math.round((telemetry.ramUsedMb / telemetry.ramTotalMb) * 100)}%
              </span>
            </div>
            <div className="text-2xl font-chakra font-black text-white">
              {(telemetry.ramUsedMb / 1024).toFixed(1)}<span className="text-sm font-normal text-slate-400"> / 16 GB</span>
            </div>
            <div className="w-full bg-[#080b10] h-1.5 rounded-full overflow-hidden mt-2">
              <div 
                style={{ width: `${(telemetry.ramUsedMb / telemetry.ramTotalMb) * 100}%` }} 
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-300"
              />
            </div>
            <div className="text-[10px] text-slate-400 font-mono-code mt-1.5 flex justify-between">
              <span>Free: {(telemetry.ramFreeMb / 1024).toFixed(1)} GB</span>
              <span className="text-purple-300">ZRAM: 8GB</span>
            </div>
          </div>

          {/* Temperature & Battery Status Card */}
          <div className="bg-[#121722]/80 border border-[#20293a] rounded-xl p-3.5 hover:border-red-500/40 transition-colors">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-chakra font-semibold flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-red-400" /> SUHU REAL-TIME
              </span>
              <span className={`font-mono-code text-[11px] font-bold ${
                telemetry.batteryTempC > 40 ? 'text-red-400 animate-pulse' : telemetry.batteryTempC > 36 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {telemetry.thermalZoneState}
              </span>
            </div>
            <div className="text-2xl font-chakra font-black text-white text-glow-red flex items-baseline justify-between">
              <span>{telemetry.batteryTempC.toFixed(1)}<span className="text-sm font-normal text-slate-400">°C</span></span>
              <span className="text-xs font-mono-code text-slate-400">SoC: {telemetry.socTempC.toFixed(0)}°C</span>
            </div>
            <div className="w-full bg-[#080b10] h-1.5 rounded-full overflow-hidden mt-2">
              <div 
                style={{ width: `${Math.min(100, (telemetry.batteryTempC / 50) * 100)}%` }} 
                className={`h-full rounded-full transition-all duration-300 ${
                  telemetry.batteryTempC > 41 ? 'bg-red-500' : telemetry.batteryTempC > 36 ? 'bg-amber-400' : 'bg-emerald-400'
                }`}
              />
            </div>
            <div className="text-[10px] text-slate-400 font-mono-code mt-1.5 flex justify-between">
              <span>Batt: {telemetry.batteryLevelPercent}%</span>
              <span className="text-emerald-400">Bypass Power OK</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. REAL-TIME THERMAL MONITOR & SMART BATTERY OPTIMIZATION */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Real-time Temperature & Thermal Zone Monitor */}
        <div className="bg-[#0d1117] border border-[#232d3d] rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#1b2330]">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 bg-red-950/70 border border-red-800/50 rounded-lg text-red-400">
                <Thermometer className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-chakra font-bold text-sm tracking-wider text-white">
                  PEMICU SUHU &amp; THERMAL THROTTLING
                </h3>
                <p className="text-xs text-slate-400 font-rajdhani">Pemantauan thermal zone real-time &amp; pencegahan throttling</p>
              </div>
            </div>

            <span className="text-[11px] font-mono-code px-2 py-0.5 rounded bg-[#161f2e] text-cyan-300 border border-cyan-800/40">
              THERMAL OVERRIDE
            </span>
          </div>

          <div className="mt-4 space-y-4">
            {/* Visual Temperature Comparison */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-[#121722] p-2.5 rounded-xl border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 font-chakra uppercase">Baterai Cell</span>
                <div className={`text-xl font-chakra font-bold ${
                  telemetry.batteryTempC > 40 ? 'text-red-400' : telemetry.batteryTempC > 36 ? 'text-amber-400' : 'text-emerald-400'
                }`}>
                  {telemetry.batteryTempC.toFixed(1)}°C
                </div>
                <span className="text-[9px] text-slate-500 font-mono-code">Batas Max 45°C</span>
              </div>

              <div className="bg-[#121722] p-2.5 rounded-xl border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 font-chakra uppercase">CPU SoC Core</span>
                <div className="text-xl font-chakra font-bold text-cyan-300">
                  {telemetry.socTempC.toFixed(1)}°C
                </div>
                <span className="text-[9px] text-slate-500 font-mono-code">Snapdragon 8 Gen 3</span>
              </div>

              <div className="bg-[#121722] p-2.5 rounded-xl border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 font-chakra uppercase">GPU Adreno</span>
                <div className="text-xl font-chakra font-bold text-amber-400">
                  {(telemetry.socTempC - 2.1).toFixed(1)}°C
                </div>
                <span className="text-[9px] text-slate-500 font-mono-code">Adreno 750 (1GHz)</span>
              </div>
            </div>

            {/* Thermal Throttling Strategy Switch */}
            <div className="space-y-1.5">
              <label className="text-xs font-chakra font-semibold text-slate-300 flex items-center justify-between">
                <span>MODE MITIGASI THERMAL (KERNEL / SYSFS)</span>
                <span className="text-xs text-red-400 font-mono-code">{kernelSettings.thermalThrottling.toUpperCase()}</span>
              </label>

              <div className="grid grid-cols-2 gap-2">
                {[
                  {
                    id: 'gaming_bypass',
                    title: 'ROG Gaming Bypass',
                    desc: 'Abaikan thermal throttling saat game aktif agar FPS tidak drop.',
                    active: kernelSettings.thermalThrottling === 'gaming_bypass',
                  },
                  {
                    id: 'aggressive_cool',
                    title: 'Aggressive Cool Fan',
                    desc: 'Turunkan clock bila suhu > 42°C untuk menjaga daya tahan baterai.',
                    active: kernelSettings.thermalThrottling === 'aggressive_cool',
                  },
                  {
                    id: 'disabled_extreme',
                    title: 'Extreme No Throttling',
                    desc: 'Stop daemon thermald & thermal-engine total via Root su.',
                    active: kernelSettings.thermalThrottling === 'disabled_extreme',
                  },
                  {
                    id: 'stock',
                    title: 'Stock OEM Thermal',
                    desc: 'Standar pabrikan Android dengan batasan throttling ketat.',
                    active: kernelSettings.thermalThrottling === 'stock',
                  },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      sounds.playClick();
                      onUpdateKernel({ thermalThrottling: item.id as any });
                    }}
                    className={`text-left p-2.5 rounded-xl border text-xs transition-all ${
                      item.active
                        ? 'bg-red-950/70 border-red-500 text-white shadow-md shadow-red-950/40'
                        : 'bg-[#121722] border-[#20293a] text-slate-400 hover:text-white hover:bg-[#161d2a]'
                    }`}
                  >
                    <div className="font-chakra font-bold text-white flex items-center justify-between">
                      <span>{item.title}</span>
                      {item.active && <CheckCircle2 className="w-3.5 h-3.5 text-red-400" />}
                    </div>
                    <p className="text-[11px] text-slate-400 font-rajdhani mt-0.5 leading-snug">{item.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Smart Battery Optimization & ROG Bypass Charging */}
        <div className="bg-[#0d1117] border border-[#232d3d] rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#1b2330]">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 bg-emerald-950/70 border border-emerald-800/50 rounded-lg text-emerald-400">
                <BatteryCharging className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-chakra font-bold text-sm tracking-wider text-white">
                  OPTIMASI BATERAI CERDAS &amp; BYPASS CHARGING
                </h3>
                <p className="text-xs text-slate-400 font-rajdhani">Bypass power direct-to-motherboard saat bermain game</p>
              </div>
            </div>

            <span className="text-[11px] font-mono-code px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/40">
              5500 mAh
            </span>
          </div>

          <div className="mt-4 space-y-4">
            {/* Bypass Charging Highlight (Crucial for Gamer thermal control) */}
            <div className={`p-3.5 rounded-xl border transition-all ${
              batterySettings.bypassChargingEnabled
                ? 'bg-gradient-to-r from-emerald-950/70 via-[#10241e] to-[#0c1914] border-emerald-500/80 shadow-md shadow-emerald-950/40'
                : 'bg-[#121722] border-[#20293a]'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Zap className={`w-4 h-4 ${batterySettings.bypassChargingEnabled ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <div>
                    <span className="font-chakra font-bold text-sm text-white">
                      ROG Bypass Charging (Direct Power)
                    </span>
                    <p className="text-xs text-slate-300 font-rajdhani">
                      Daya dialirkan langsung ke chipset tanpa mengisi baterai. 0% panas pengisian daya!
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    sounds.playToggle(!batterySettings.bypassChargingEnabled);
                    onUpdateBattery({ bypassChargingEnabled: !batterySettings.bypassChargingEnabled });
                  }}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors ${
                    batterySettings.bypassChargingEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    batterySettings.bypassChargingEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>

            {/* Smart Battery Modes */}
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'gaming_bypass', label: 'Gaming Bypass', desc: 'Arus max ke SoC, baterai idle 0W' },
                { id: 'balanced_ai', label: 'AI Adaptive', desc: 'Otomatis sesuaikan watt pengisian' },
                { id: 'cooldown_guard', label: 'Cooldown Guard', desc: 'Stop charging bila suhu > 40°C' },
                { id: 'ultra_saver', label: 'Extreme Saver', desc: 'Batas 60Hz + kill background total' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    sounds.playClick();
                    onUpdateBattery({ mode: m.id as any });
                  }}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    batterySettings.mode === m.id
                      ? 'bg-emerald-950/60 border-emerald-500 text-white'
                      : 'bg-[#121722] border-[#20293a] text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="font-chakra font-bold text-white flex items-center justify-between">
                    <span>{m.label}</span>
                    {batterySettings.mode === m.id && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                  </div>
                  <p className="text-[11px] text-slate-400 font-rajdhani mt-0.5">{m.desc}</p>
                </button>
              ))}
            </div>

            {/* Charging Cap Slider */}
            <div className="bg-[#121722] p-3 rounded-xl border border-[#20293a] space-y-2">
              <div className="flex items-center justify-between text-xs font-chakra">
                <span className="text-slate-300">Batas Maksimal Pengisian Baterai:</span>
                <span className="text-emerald-400 font-mono-code font-bold">{batterySettings.chargeLimitPercent}%</span>
              </div>
              <input
                type="range"
                min="70"
                max="100"
                step="5"
                value={batterySettings.chargeLimitPercent}
                onChange={(e) => {
                  onUpdateBattery({ chargeLimitPercent: Number(e.target.value) });
                }}
                className="w-full accent-emerald-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono-code">
                <span>70% (Baterai Super Awet)</span>
                <span>80% (Standar ROG)</span>
                <span>100% (Penuh)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. KERNEL CUSTOMIZATION PANEL */}
      <section className="bg-[#0d1117] border border-[#232d3d] rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1b2330] gap-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-cyan-950/70 border border-cyan-800/50 rounded-lg text-cyan-400">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-chakra font-bold text-base tracking-wider text-white">
                KUSTOMISASI KERNEL &amp; TUNING PERFORMA TINGKAT LANJUT
              </h3>
              <p className="text-xs text-slate-400 font-rajdhani">
                Pengaturan Governor CPU/GPU, I/O Scheduler, ZRAM, Touch &amp; Layar 165Hz
              </p>
            </div>
          </div>

          {/* Sub Navigation Tabs */}
          <div className="flex items-center space-x-1 bg-[#131924] p-1 rounded-xl border border-[#20293a]">
            {[
              { id: 'cpu', label: 'CPU Cores' },
              { id: 'gpu', label: 'GPU Clocks' },
              { id: 'memory', label: 'RAM / ZRAM' },
              { id: 'display', label: 'Display & Touch' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  sounds.playClick();
                  setActiveKernelTab(t.id as any);
                }}
                className={`px-3 py-1 text-xs font-chakra font-bold rounded-lg transition-all ${
                  activeKernelTab === t.id
                    ? 'bg-cyan-500 text-black font-extrabold shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab 1: CPU Clocks & Governors */}
        {activeKernelTab === 'cpu' && (
          <div className="mt-5 space-y-4">
            {/* Governor Selector */}
            <div className="bg-[#121722] p-4 rounded-xl border border-[#20293a]">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-xs font-chakra font-bold text-white tracking-wider">
                    CPU SCALING GOVERNOR
                  </h4>
                  <p className="text-xs text-slate-400 font-rajdhani">Mengatur perilaku penjadwalan frekuensi cluster CPU</p>
                </div>
                <span className="text-xs font-mono-code text-cyan-400 uppercase bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                  {kernelSettings.cpuGovernor}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: 'performance', name: 'Performance', desc: 'Kunci clock maksimum' },
                  { id: 'schedutil', name: 'Schedutil', desc: 'Bawaan EAS scheduler' },
                  { id: 'ondemand', name: 'Ondemand', desc: 'Respon cepat saat load' },
                  { id: 'conservative', name: 'Conservative', desc: 'Menaikkan clock bertahap' },
                  { id: 'powersave', name: 'Powersave', desc: 'Kunci clock paling rendah' },
                ].map((gov) => (
                  <button
                    key={gov.id}
                    onClick={() => {
                      sounds.playClick();
                      onUpdateKernel({ cpuGovernor: gov.id as any });
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      kernelSettings.cpuGovernor === gov.id
                        ? 'bg-gradient-to-br from-cyan-950 to-blue-950 border-cyan-400 text-white shadow-md shadow-cyan-950/50'
                        : 'bg-[#151b26] border-[#222d3e] text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-chakra font-bold text-white flex items-center justify-between">
                      <span>{gov.name}</span>
                      {kernelSettings.cpuGovernor === gov.id && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                    </div>
                    <p className="text-[10px] text-slate-400 font-rajdhani mt-0.5">{gov.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Cluster Freq Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {telemetry.cpuClusters.map((cluster, idx) => (
                <div key={idx} className="bg-[#121722] border border-[#20293a] rounded-xl p-3.5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-chakra font-bold text-white">{cluster.name}</span>
                    <span className="text-xs font-mono-code text-cyan-400 font-semibold">{cluster.loadPercent}% load</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono-code">{cluster.cores}</div>
                  <div className="text-xl font-chakra font-black text-white mt-2">
                    {cluster.currentFreqMhz} <span className="text-xs font-normal text-slate-400">MHz</span>
                  </div>
                  <div className="w-full bg-[#090d14] h-1.5 rounded-full overflow-hidden mt-1.5">
                    <div 
                      style={{ width: `${(cluster.currentFreqMhz / cluster.maxFreqMhz) * 100}%` }}
                      className="h-full bg-cyan-400 rounded-full"
                    />
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono-code mt-1.5 flex justify-between">
                    <span>Min: {cluster.minFreqMhz}MHz</span>
                    <span>Max: {cluster.maxFreqMhz}MHz</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: GPU Clocks */}
        {activeKernelTab === 'gpu' && (
          <div className="mt-5 space-y-4">
            <div className="bg-[#121722] p-4 rounded-xl border border-[#20293a] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-chakra font-bold text-white tracking-wider">
                    GPU GOVERNOR &amp; ADRENOBOOST TUNER
                  </h4>
                  <p className="text-xs text-slate-400 font-rajdhani">Akselerasi grafis Adreno 750 untuk rendering game 120-165 FPS</p>
                </div>
                <span className="text-xs font-mono-code text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">
                  {kernelSettings.gpuGovernor}
                </span>
              </div>

              {/* GPU Governors */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'msm-adreno-tz', name: 'msm-adreno-tz', desc: 'Trustzone OEM optimal' },
                  { id: 'performance', name: 'Performance', desc: 'Maksimum 1000 MHz konstan' },
                  { id: 'simple_ondemand', name: 'Simple Ondemand', desc: 'Respon cepat frekuensi' },
                  { id: 'powersave', name: 'Powersave', desc: 'Minimal clock 220 MHz' },
                ].map((g) => (
                  <button
                    key={g.id}
                    onClick={() => {
                      sounds.playClick();
                      onUpdateKernel({ gpuGovernor: g.id as any });
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      kernelSettings.gpuGovernor === g.id
                        ? 'bg-amber-950/60 border-amber-500 text-white'
                        : 'bg-[#151b26] border-[#222d3e] text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-chakra font-bold text-white flex items-center justify-between">
                      <span>{g.name}</span>
                      {kernelSettings.gpuGovernor === g.id && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                    <p className="text-[10px] text-slate-400 font-rajdhani mt-0.5">{g.desc}</p>
                  </button>
                ))}
              </div>

              {/* AdrenoBoost Level */}
              <div className="pt-2">
                <div className="flex items-center justify-between text-xs font-chakra mb-1.5">
                  <span className="text-slate-300">AdrenoBoost Kernel Level:</span>
                  <span className="text-amber-400 font-bold uppercase">{kernelSettings.adrenoBoostLevel}</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(['off', 'low', 'medium', 'high'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => {
                        sounds.playClick();
                        onUpdateKernel({ adrenoBoostLevel: lvl });
                      }}
                      className={`py-2 rounded-lg font-chakra font-bold text-xs uppercase border transition-all ${
                        kernelSettings.adrenoBoostLevel === lvl
                          ? 'bg-amber-500 text-black border-amber-400 font-extrabold shadow'
                          : 'bg-[#141b27] border-[#232d3d] text-slate-400 hover:text-white'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: RAM & ZRAM */}
        {activeKernelTab === 'memory' && (
          <div className="mt-5 space-y-4">
            <div className="bg-[#121722] p-4 rounded-xl border border-[#20293a] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-chakra font-bold text-white tracking-wider">
                    VIRTUAL MEMORY &amp; ZRAM COMPRESSION
                  </h4>
                  <p className="text-xs text-slate-400 font-rajdhani">Optimasi paging swappiness &amp; kompresi memori virtual</p>
                </div>
                <span className="text-xs font-mono-code text-purple-400 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800/40">
                  SWAP: {kernelSettings.swappinessPercent}%
                </span>
              </div>

              {/* Swappiness Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-chakra">
                  <span className="text-slate-300">Kernel Swappiness:</span>
                  <span className="text-purple-400 font-mono-code font-bold">{kernelSettings.swappinessPercent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={kernelSettings.swappinessPercent}
                  onChange={(e) => onUpdateKernel({ swappinessPercent: Number(e.target.value) })}
                  className="w-full accent-purple-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono-code">
                  <span>0% (Hanya RAM Fisik)</span>
                  <span>60% (Optimal Gaming)</span>
                  <span>100% (Maksimal Multitasking)</span>
                </div>
              </div>

              {/* I/O Scheduler & TCP Algorithm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="space-y-1.5">
                  <label className="text-xs font-chakra text-slate-300">I/O SCHEDULER (STORAGE UFS 4.0):</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['mq-deadline', 'kyber', 'bfq'] as const).map((sched) => (
                      <button
                        key={sched}
                        onClick={() => {
                          sounds.playClick();
                          onUpdateKernel({ ioScheduler: sched });
                        }}
                        className={`py-1.5 text-xs font-mono-code rounded border ${
                          kernelSettings.ioScheduler === sched
                            ? 'bg-purple-950/80 text-purple-300 border-purple-500'
                            : 'bg-[#151b26] border-[#222d3e] text-slate-400 hover:text-white'
                        }`}
                      >
                        {sched}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-chakra text-slate-300">TCP CONGESTION (JARINGAN PING RENDAH):</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['bbr', 'cubic', 'westwood'] as const).map((tcp) => (
                      <button
                        key={tcp}
                        onClick={() => {
                          sounds.playClick();
                          onUpdateKernel({ tcpCongestion: tcp });
                        }}
                        className={`py-1.5 text-xs font-mono-code rounded border ${
                          kernelSettings.tcpCongestion === tcp
                            ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500'
                            : 'bg-[#151b26] border-[#222d3e] text-slate-400 hover:text-white'
                        }`}
                      >
                        {tcp.toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Display & Touch */}
        {activeKernelTab === 'display' && (
          <div className="mt-5 space-y-4">
            <div className="bg-[#121722] p-4 rounded-xl border border-[#20293a] space-y-4">
              {/* Refresh Rate Lock */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-chakra font-bold text-white uppercase">
                    KUNCI DISPLAY REFRESH RATE (SURFACEFLINGER)
                  </span>
                  <span className="text-xs font-mono-code text-cyan-400 font-bold">
                    {kernelSettings.displayRefreshRateHz} Hz
                  </span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {([60, 90, 120, 144, 165] as const).map((hz) => (
                    <button
                      key={hz}
                      onClick={() => {
                        sounds.playClick();
                        onUpdateKernel({ displayRefreshRateHz: hz });
                      }}
                      className={`py-2 rounded-xl border font-chakra font-bold text-xs transition-all ${
                        kernelSettings.displayRefreshRateHz === hz
                          ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-950/50'
                          : 'bg-[#141b27] border-[#232d3d] text-slate-400 hover:text-white'
                      }`}
                    >
                      {hz} Hz
                    </button>
                  ))}
                </div>
              </div>

              {/* Touch Sampling Rate */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-chakra font-bold text-white uppercase">
                    TOUCH SAMPLING RATE (ROG ULTRA SENSITIVE)
                  </span>
                  <span className="text-xs font-mono-code text-red-400 font-bold">
                    {kernelSettings.touchSamplingRateHz} Hz
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {([240, 360, 480, 720] as const).map((hz) => (
                    <button
                      key={hz}
                      onClick={() => {
                        sounds.playClick();
                        onUpdateKernel({ touchSamplingRateHz: hz });
                      }}
                      className={`py-2 rounded-xl border font-chakra font-bold text-xs transition-all ${
                        kernelSettings.touchSamplingRateHz === hz
                          ? 'bg-red-600 text-white border-red-400 glow-red-sm'
                          : 'bg-[#141b27] border-[#232d3d] text-slate-400 hover:text-white'
                      }`}
                    >
                      {hz} Hz
                    </button>
                  ))}
                </div>
              </div>

              {/* Graphic Switches */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="flex items-center justify-between p-3 bg-[#161d2b] rounded-xl border border-[#232f42]">
                  <div>
                    <span className="text-xs font-chakra font-bold text-white">Disable HW Overlays</span>
                    <p className="text-[11px] text-slate-400 font-rajdhani">Gunakan GPU langsung untuk komposisi layar</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={kernelSettings.disableHwOverlays}
                    onChange={(e) => onUpdateKernel({ disableHwOverlays: e.target.checked })}
                    className="w-4 h-4 accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between p-3 bg-[#161d2b] rounded-xl border border-[#232f42]">
                  <div>
                    <span className="text-xs font-chakra font-bold text-white">Force 2D GPU Rendering</span>
                    <p className="text-[11px] text-slate-400 font-rajdhani">Akselerasi antarmuka grafik dengan OpenGLES</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={kernelSettings.forceGpuRendering}
                    onChange={(e) => onUpdateKernel({ forceGpuRendering: e.target.checked })}
                    className="w-4 h-4 accent-cyan-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* 4. DEEP RAM CLEANER & BACKGROUND APPS KILLER */}
      <section className="bg-[#0d1117] border border-[#232d3d] rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1b2330] gap-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-purple-950/70 border border-purple-800/50 rounded-lg text-purple-400">
              <Trash2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-chakra font-bold text-base tracking-wider text-white">
                SCAN &amp; PEMBERSIH LATAR BELAKANG (RAM CLEAR)
              </h3>
              <p className="text-xs text-slate-400 font-rajdhani">
                Scan aplikasi yang membebani memori, hentikan proses latar belakang secara paksa via Root/Shizuku
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                sounds.playClick();
                onScanApps();
              }}
              disabled={isScanning}
              className="px-3.5 py-1.5 bg-[#141b27] hover:bg-[#1f2838] border border-[#232d3d] rounded-xl text-xs font-chakra font-bold text-slate-300 flex items-center space-x-1.5 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'SCANNING APPS...' : 'SCAN ULANG'}</span>
            </button>

            <button
              onClick={() => {
                sounds.playBoostClean();
                onKillAllApps();
              }}
              className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-chakra font-bold flex items-center space-x-1.5 shadow-md shadow-red-950/60 transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>HENTIKAN SEMUA ({totalKillableRamMb} MB)</span>
            </button>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center space-x-2 mt-4 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', label: 'Semua Aplikasi' },
            { id: 'social', label: 'Media Sosial' },
            { id: 'bloatware', label: 'Bloatware & Analytics' },
            { id: 'games', label: 'Game Apps' },
            { id: 'media', label: 'Media & Browser' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                sounds.playClick();
                setAppCategoryFilter(cat.id as any);
              }}
              className={`px-3 py-1 rounded-lg font-chakra font-semibold whitespace-nowrap transition-colors ${
                appCategoryFilter === cat.id
                  ? 'bg-slate-200 text-black font-bold'
                  : 'bg-[#121722] text-slate-400 hover:text-white border border-[#20293a]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Process List */}
        <div className="mt-3.5 divide-y divide-[#18202d] border border-[#20293a] rounded-xl overflow-hidden bg-[#0c1017]">
          {filteredApps.map((app) => (
            <div 
              key={app.id} 
              className={`p-3.5 flex items-center justify-between transition-colors ${
                app.isKilled ? 'opacity-40 bg-black/40' : 'hover:bg-[#121722]'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-chakra font-bold text-xs ${
                  app.category === 'games' 
                    ? 'bg-red-950/80 text-red-400 border border-red-700/50' 
                    : app.category === 'bloatware'
                    ? 'bg-amber-950/80 text-amber-400 border border-amber-700/50'
                    : 'bg-cyan-950/80 text-cyan-400 border border-cyan-700/50'
                }`}>
                  {app.name.charAt(0)}
                </div>

                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-chakra font-bold text-sm text-white">{app.name}</span>
                    {app.isWhitelisted && (
                      <span className="text-[9px] px-1.5 py-0.2 bg-emerald-950 text-emerald-400 rounded border border-emerald-800/40">
                        WHITELIST
                      </span>
                    )}
                    {app.isKilled && (
                      <span className="text-[9px] px-1.5 py-0.2 bg-slate-800 text-slate-400 rounded">
                        KILLED (0 MB)
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 font-mono-code">
                    {app.packageName} • Aktif {app.runningSinceMinutes} mnt
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right font-mono-code text-xs">
                  <div className="font-bold text-slate-200">{app.isKilled ? '0' : app.ramMb} MB</div>
                  <div className="text-[11px] text-slate-500">{app.isKilled ? '0%' : `${app.cpuPercent}% CPU`}</div>
                </div>

                <button
                  onClick={() => {
                    sounds.playClick();
                    onKillApp(app.id);
                  }}
                  disabled={app.isKilled}
                  className={`px-3 py-1 rounded-lg text-xs font-chakra font-semibold border transition-all ${
                    app.isKilled
                      ? 'bg-transparent text-slate-600 border-slate-800 cursor-not-allowed'
                      : 'bg-red-950/60 hover:bg-red-800 text-red-400 hover:text-white border-red-800/60'
                  }`}
                >
                  {app.isKilled ? 'TERHENTI' : 'STOP APK'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
